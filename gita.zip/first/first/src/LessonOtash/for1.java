package LessonOtash;

import java.util.Scanner;

public class for1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        for (int i = 9; i >= 1; i--) {
            for (int j = 0; j < 10; j++) {
                if (i % 2 == 0 )
                    System.out.print(i);
            }
            System.out.println();
        }
    }
}
