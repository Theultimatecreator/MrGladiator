package LessonOtash;

import java.util.Scanner;

public class mmm {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        for (int i = 1; i < 10; i++) {
            for (int j = 1; j < 10; j++) {
                if (i % 2 == 0 && j % 2 == 1 || j % 2 == 0 && i % 2 == 1)
                    System.out.print(i + " ");
                else
                    System.out.print("*" + " ");
            }
            System.out.println();
        }
    }
}
