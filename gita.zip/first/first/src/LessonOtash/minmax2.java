package LessonOtash;

import java.util.Scanner;

public class minmax2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a = in.nextInt();
        int b = in.nextInt();
        int Smin = a * b;
        for (int i = 1; i < n; i++) {
            int c = in.nextInt();
            int d = in.nextInt();
            int e = c * d;
            if (Smin > e) {
                Smin = e;
            }

        }
        System.out.println("minimal yuza = " + Smin);

    }
}
