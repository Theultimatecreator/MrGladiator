package LessonOtash;

import java.util.Scanner;

public class minmax1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int min = in.nextInt();
        int max = min;
        for (int i = 1; i < n; i++) {
            int a = in.nextInt();
            if (min > a) {
                min = a;
            }
            if (max < a) {
                max = a;
            }

        }
        System.out.println(min);
        System.out.println(max);
    }
}
