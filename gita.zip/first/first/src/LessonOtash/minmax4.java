package LessonOtash;

import java.util.Scanner;

public class minmax4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int min = in.nextInt();
        int indexMin = 1;
        for (int i = 2; i <= n; i++) {
            int a = in.nextInt();
            if (min >= a) {
                min = a;
                indexMin = i;
            }
        }
        System.out.println("minimal index = " + indexMin);
    }
}
