package p_01_begin;

import java.util.Scanner;

public class begin3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a, b, s, p;
        System.out.print("a = ");
        a = in.nextInt();
        System.out.print("b = ");
        b = in.nextInt();
        p = 2 * (a + b);
        s = a * b;
        System.out.println("Perimetri = " + p);
        System.out.println("Yuzasi = " + s);
    }
}
