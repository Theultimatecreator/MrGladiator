package p_01_begin;

import java.util.Scanner;

public class begin26 {
    public static void main(String[] args) {
        int x;
        Scanner in = new Scanner(System.in);
        System.out.print("x = ");
        x = in.nextInt();

        double y = 4 * Math.pow(x - 3, 6) - 7 * Math.pow(x - 3, 3) + 2;
        System.out.println("y = " + y);

    }
}
