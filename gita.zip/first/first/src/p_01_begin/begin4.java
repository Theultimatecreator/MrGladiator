package p_01_begin;

import java.util.Scanner;

public class begin4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double d, p = 3.14, l;
        System.out.print("d = ");
        d = in.nextDouble();
        l = p * d;
        System.out.println("Aylana uzunligi = " + l);

    }
}
