package p_01_begin;

import java.util.Scanner;

public class begin17 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double A, B, C;
        System.out.print("A = ");
        A = in.nextDouble();
        System.out.print("B = ");
        B = in.nextDouble();
        System.out.print("C = ");
        C = in.nextDouble();
        System.out.println("AC kesma uzunligi = " + Math.abs(C - A));
        System.out.println("BC kesma uzunligi = " + Math.abs(B - C));
        System.out.println("Kesmalar yigindis = " + (Math.abs(C - A) + Math.abs(B - C)));
    }
}
