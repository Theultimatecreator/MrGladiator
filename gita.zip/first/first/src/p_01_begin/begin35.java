package p_01_begin;

import java.util.Scanner;

public class begin35 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int v, u, t1, t2, s;
        System.out.println("v = ");
        v = in.nextInt();
        System.out.println("u = ");
        u = in.nextInt();
        System.out.println("t1 = ");
        t1 = in.nextInt();
        System.out.println("t2 = ");
        t2 = in.nextInt();
        s = (v + u) / t1;
        System.out.println("1-holda masofa = " + s);
        s = (v - u) / t2;
        System.out.println("2- holda masofa = " + s);

    }
}
