package p_01_begin;

import java.util.Scanner;

public class begin11 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        double a, b;
        System.out.print("a = ");
        a = in.nextDouble();
        System.out.print("b = ");
        b = in.nextDouble();

        System.out.println("Yig`indisi = " + (a + b));
        System.out.println("Ko`paytmasi = " + (a * b));
        System.out.println("a moduli = " + Math.abs(a));
        System.out.println("b moduli = " + Math.abs(b));
    }
}
