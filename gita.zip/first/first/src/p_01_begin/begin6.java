package p_01_begin;

import java.util.Scanner;

public class begin6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double R, l, s, p = 3.14;
        System.out.print("R = ");
        R = in.nextDouble();
        l  = 2 * p * R;
        s = p * R * R;
        System.out.println("Doira uzunligi = " + l);
        System.out.println("Doira yuzasi = " + s);
    }
}
