package p_01_begin;

import java.util.Scanner;

public class begin31 {
    public static void main(String[] args) {
        int Tf;
        Scanner in = new Scanner(System.in);
        System.out.print("Tf = ");
        Tf = in.nextInt();

        double Tc = (Tf - 32) * 5 / 9;
        System.out.println("natija = " + Tc);

    }
}
