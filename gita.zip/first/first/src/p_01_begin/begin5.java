package p_01_begin;

import java.util.Scanner;

public class begin5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a, b, c, s, v;
        System.out.print("a = ");
        a = in.nextInt();
        System.out.print("b = ");
        b = in.nextInt();
        System.out.print("c = ");
        c = in.nextInt();

        v = a * b * c;
        s = 2 * (a * b + b * c + a * c);
        System.out.println("Hajmi = " + v);
        System.out.println("Yuzasi = " + s);
    }
}
