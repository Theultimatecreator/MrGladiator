package p_01_begin;

import java.util.Scanner;

public class begin39 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double A, B, C, x1, x2, D;
        System.out.print("A = ");
        A = in.nextDouble();
        System.out.print("B = ");
        B = in.nextDouble();
        System.out.print("C = ");
        C = in.nextDouble();
        D = B * B - 4 * A * C;
        System.out.print("Deskriminant = " + D);
        x1 = (-B + Math.sqrt(D)) / 2 * A;
        System.out.print("x1 = " + x1);
        x2 = (-B - Math.sqrt(D)) / 2 * A;
        System.out.print("x2 = " + x2);
    }
}
