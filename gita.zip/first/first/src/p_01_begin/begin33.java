package p_01_begin;

import java.util.Scanner;

public class begin33 {
    public static void main(String[] args) {
        int x, a, y;
        Scanner in = new Scanner(System.in);
        System.out.print("x = ");
        x = in.nextInt();
        System.out.print("a = ");
        a = in.nextInt();
        System.out.print("y = ");
        y = in.nextInt();

        double bir_kg = a / x;
        System.out.println("bir kilosi = " + bir_kg);
        double y_kilosi = a / x * y;
        System.out.println("y kilosi = " + y_kilosi);

    }
}
