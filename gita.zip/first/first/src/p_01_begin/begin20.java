package p_01_begin;

import java.util.Scanner;

public class begin20 {
    public static void main(String[] args) {
        double X1, X2, Y1, Y2;
        Scanner in = new Scanner(System.in);
        System.out.print("X1 = ");
        X1 = in.nextDouble();
        System.out.print("X2 = ");
        X2 = in.nextDouble();
        System.out.print("Y1 = ");
        Y1 = in.nextDouble();
        System.out.print("Y2 = ");
        Y2 = in.nextDouble();
        System.out.println("Natija = " + Math.sqrt(Math.pow(X2 - X1, 2) + Math.pow(Y2 - Y1, 2)));

    }
}
