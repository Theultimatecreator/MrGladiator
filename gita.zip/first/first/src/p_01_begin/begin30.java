package p_01_begin;

import java.util.Scanner;

public class begin30 {
    public static void main(String[] args) {
        int radian;
        Scanner in = new Scanner(System.in);
        System.out.print("radian = ");
        radian = in.nextInt();

        double alfa = 180 / radian;
        System.out.println("natija = " + alfa);

    }
}
