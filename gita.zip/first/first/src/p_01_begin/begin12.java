package p_01_begin;

import java.util.Scanner;

public class begin12 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        double a, b, c, p;
        System.out.print("a = ");
        a = in.nextDouble();
        System.out.print("b = ");
        b = in.nextDouble();
        c = Math.sqrt(a * a + b * b);
        p = a + b + c;
        System.out.println("Gipotinuza = " + c);
        System.out.println("Perimetri = " + p);

    }
}
