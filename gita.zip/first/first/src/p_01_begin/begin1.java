package p_01_begin;

import java.util.Scanner;

public class begin1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a, p;
        System.out.print("a = ");
        a = in.nextInt();
        p = 4 * a;
        System.out.println("Perimetri = " + p);
    }

}
