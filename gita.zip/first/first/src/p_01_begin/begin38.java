package p_01_begin;

import java.util.Scanner;

public class begin38 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double A, B, x;

        System.out.print("A = ");
        A = in.nextDouble();
        System.out.print("B = ");
        B = in.nextDouble();
        x = -B / A;
        System.out.print("natija = " + x);
    }
}
