package p_01_begin;

import java.util.Scanner;

public class begin2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a, s;
        System.out.print("a = ");
        a = in.nextInt();
        s = a * a;
        System.out.println("Yuza = " + s);
    }
}
