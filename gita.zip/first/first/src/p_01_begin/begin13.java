package p_01_begin;

import java.util.Scanner;

public class begin13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double R1, R2, S1, S2, S3, p = 3.14;
        System.out.print("R1 = ");
        R1 = in.nextDouble();
        System.out.print("R2 = ");
        R2 = in.nextDouble();
        S1 = p * R1;
        S2 = p * R2;
        S3 = p * (R1 - R2);
        System.out.println("S1 = " + S1);
        System.out.println("S2 = " + S2);
        System.out.println("ayirmasi = " + S3);


    }
}
