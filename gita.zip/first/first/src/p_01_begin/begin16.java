package p_01_begin;

import java.util.Scanner;

public class begin16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double X2, X1;
        System.out.print("X2 = ");
        X2 = in.nextDouble();
        System.out.print("X1 = ");
        X1 = in.nextDouble();

        System.out.println("Ikki nuqta orasidagi masofa = " + Math.abs(X2 - X1));
    }
}
