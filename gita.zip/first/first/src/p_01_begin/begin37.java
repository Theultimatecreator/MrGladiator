package p_01_begin;

import java.util.Scanner;

public class begin37 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int v1, v2, t, s;
        System.out.print("v1 = ");
        v1 = in.nextInt();
        System.out.print("v2 = ");
        v2 = in.nextInt();
        System.out.print("t = ");
        t = in.nextInt();
        s = (v1 - v2) * t;
        System.out.println("masofa = " + s);
    }
}
