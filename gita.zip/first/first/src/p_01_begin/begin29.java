package p_01_begin;

import java.util.Scanner;

public class begin29 {
    public static void main(String[] args) {
        int alfa;
        Scanner in = new Scanner(System.in);
        System.out.print("burchak = ");
        alfa = in.nextInt();

        double radian = alfa * 57.3;
        System.out.println("natija = " + radian);

    }
}
