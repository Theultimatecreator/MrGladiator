package p_01_begin;

import java.util.Scanner;

public class begin27 {
    public static void main(String[] args) {
        int a, n;
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        a = in.nextInt();
        System.out.print("daraja = ");
        n = in.nextInt();

        double natija = Math.pow(a, n);
        System.out.println("natija = " + natija);

    }
}
