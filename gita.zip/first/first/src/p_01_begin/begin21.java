package p_01_begin;

import java.util.Scanner;

public class begin21 {
    public static void main(String[] args) {
        double X1, X2, Y1, Y2, X3, Y3, a, b, c, s, p;
        Scanner in = new Scanner(System.in);
        System.out.print("X1 = ");
        X1 = in.nextDouble();
        System.out.print("X2 = ");
        X2 = in.nextDouble();
        System.out.print("Y1 = ");
        Y1 = in.nextDouble();
        System.out.print("Y2 = ");
        Y2 = in.nextDouble();
        System.out.print("X3 = ");
        X3 = in.nextDouble();
        System.out.print("Y3 = ");
        Y3 = in.nextDouble();
        a = Math.sqrt(Math.pow(X2 - X1, 2) + Math.pow(Y2 - Y1, 2));
        b = Math.sqrt(Math.pow(X3 - X2, 2) + Math.pow(Y3 - Y2, 2));
        c = Math.sqrt(Math.pow(X3 - X1, 2) + Math.pow(Y3 - Y1, 2));
        p = (a + b + c) / 2;
        s = Math.sqrt(p * (p - a) * (p - b) * (p - c));
        System.out.println("a tomon = " + a);
        System.out.println("b tomon = " + b);
        System.out.println("c tomon = " + c);
        System.out.println("yuza =" + s);
        System.out.println("Perimetr" + p);

    }
}
