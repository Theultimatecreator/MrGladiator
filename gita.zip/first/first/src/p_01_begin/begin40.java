package p_01_begin;

import java.util.Scanner;

public class begin40 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double A1, B1, C1, A2, B2, C2, x, y, D;
        System.out.print("A1 = ");
        A1 = in.nextDouble();
        System.out.print("B1 = ");
        B1 = in.nextDouble();
        System.out.print("C1 = ");
        C1 = in.nextDouble();
        System.out.print("A2 = ");
        A2 = in.nextDouble();
        System.out.print("B2 = ");
        B2 = in.nextDouble();
        System.out.print("C2 = ");
        C2 = in.nextDouble();
        D = (A1 * B2 - A2 * B1);
        System.out.println("D = " + D);
        x = (C1 * B2 - C2 * B1) / D;
        System.out.println("x = " + x);
        y = (A1 * C2 - A2 * C1) / D;
        System.out.println("y = " + y);
    }
}
