package p_01_begin;

public class begin19 {
}
