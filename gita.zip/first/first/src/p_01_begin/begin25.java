package p_01_begin;

import java.util.Scanner;

public class begin25 {
    public static void main(String[] args) {
        int x;
        Scanner in = new Scanner(System.in);
        System.out.print("x = ");
        x = in.nextInt();

        double y = 3 * Math.pow(x, 6) - 6 * x * x - 7;
        System.out.println("y = " + y);

    }
}
