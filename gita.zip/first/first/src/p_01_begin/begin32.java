package p_01_begin;

import java.util.Scanner;

public class begin32 {
    public static void main(String[] args) {
        int Tc;
        Scanner in = new Scanner(System.in);
        System.out.print("Tc = ");
        Tc = in.nextInt();

        double Tf = (Tc - 32) * 5 / 9;
        System.out.println("natija = " + Tf);

    }
}
