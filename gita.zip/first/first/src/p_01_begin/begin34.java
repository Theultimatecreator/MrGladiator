package p_01_begin;

import java.util.Scanner;

public class begin34 {
    public static void main(String[] args) {
        int x, a, y, b;
        Scanner in = new Scanner(System.in);
        System.out.print("x shokolad= ");
        x = in.nextInt();
        System.out.print("a = ");
        a = in.nextInt();
        System.out.print("y konfet= ");
        y = in.nextInt();
        System.out.print("b = ");
        b= in.nextInt();

        double shokolad = a / x;
        System.out.println("bir kg shokolad = " + shokolad);
        double konfet = b / y;
        System.out.println("bir kg konfet = " + konfet);
        System.out.println("farqi = " + (shokolad - konfet));
    }
}
