package lessonSatr;

import java.util.Scanner;

public class string18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr kiriting: ");
        String str = in.nextLine();
        String a = "";
        char k = 0;
        for (int i = 0; i < str.length(); i++) {
            k = str.charAt(i);
            if (Character.isUpperCase(k)) {
                k = Character.toLowerCase(k);
            } else{
                k = Character.toUpperCase(k);
            }

                a += k;
        }
        str = a;
        System.out.println(str);

    }
}