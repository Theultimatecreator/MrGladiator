package lessonSatr;

import java.util.Scanner;

public class string19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr kiriting: ");
        String str = in.nextLine();
        for (int i = 0; i < 10; i++) {
            str = str.replace("" + i, "");

        }
        int k = str.length() >= 2 ? 0:str.contains(".")?2:str.length()==1?0:1;
        System.out.println(k);
    }
}