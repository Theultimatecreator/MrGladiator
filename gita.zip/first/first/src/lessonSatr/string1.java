package lessonSatr;

import java.util.Scanner;

public class string1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        char letter = 'A';
        for (int i = 1; i <= n; i++) {
            System.out.print(letter++ + " ");
        }
    }
}


class string7 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        System.out.println((int) str.charAt(0) + " " + (int) str.charAt(str.length() - 1));
    }
}

class string9 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str1 = in.nextLine();
        String str2 = in.nextLine();
        System.out.println(str1.concat(" " + str2));
        System.out.println(str1 + " " + str2);
    }
}

class string10 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        String c = "";
        for (int i = 0; i < str.length(); i++) {
            c = str.charAt(i) + c;
        }
        System.out.println(c);
    }
}

class string13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr kiriting: ");
        String str = in.nextLine();
        int k = 0;
        for (int i = 0; i < str.length(); i++) {
            if (Character.isDigit(str.charAt(i)))
                k++;
        }
        System.out.println("raqamlar soni = " + k);
    }
}

class string14 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr kiriting: ");
        String str = in.nextLine();
        int k = 0;
        for (int i = 0; i < str.length(); i++) {
            if ('A' <= str.charAt(i) && str.charAt(i) <= 'Z')
                k++;
        }
        System.out.println("katta harflar soni = " + k);
    }
}

class string15 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr kiriting: ");
        String str = in.nextLine();
        int k = 0;
        for (int i = 0; i < str.length(); i++) {
            if ('a' <= str.charAt(i) && str.charAt(i) <= 'z')
                k++;
            else if ('а' <= str.charAt(i) && str.charAt(i) <= 'я')
                k++;
        }
        System.out.println("kichik harflar soni = " + k);
    }
}