package lessonSatr;

import java.util.Scanner;

public class string16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr kiriting: ");
        String str = in.nextLine();
        String a = "";
        char k = 0;
        for (int i = 0; i < str.length(); i++) {
            if ('A' <= str.charAt(i) && str.charAt(i) <= 'Z')
                k = (char) ('a' + str.charAt(i) - 'A');
            else
                k = str.charAt(i);
            a += k;
        }
        str = a;
        System.out.println(str);

    }
}