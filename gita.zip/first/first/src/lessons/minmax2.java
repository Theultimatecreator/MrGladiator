package lessons;

import java.util.Scanner;

public class minmax2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a = in.nextInt();
        int b = in.nextInt();
        int min = a * b;
        int max = min;
        for (int i = 1; i < n; i++) {
            int c = in.nextInt();
            int d = in.nextInt();
            int s2 = c * d;
            if (min > s2) {
                min = s2;
            }
            if (max < s2) {
                max = s2;
            }
        }
        System.out.println("Eng kichik yuza = " + min);
        System.out.println("Eng katta yuza = " + max);
    }
}
