package lessons;

import java.util.Scanner;

public class while22 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int i = 2;
        boolean tub = true;
        while (n > i) {
            if (n % i == 0) {
                tub = false;
                break;
            }
            i++;
        }
        System.out.println(tub);
    }
}
