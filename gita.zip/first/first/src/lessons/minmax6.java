package lessons;

import java.util.Scanner;

public class minmax6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int min = in.nextInt();
        int max = min;
        int indexMin = 1;
        int indexMax = 1;
        for (int i = 2; i <= n; i++) {
            int a = in.nextInt();
            if (min > a) {
                min = a;
                indexMin = i;
            }
            if (max <= a) {
                max = a;
                indexMax = i;
            }
        }
        System.out.println("birinchi uchragan min = " + indexMin);
        System.out.println("oxirgi uchragan max = " + indexMax);
    }
}
