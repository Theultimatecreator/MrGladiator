package lessons;

import java.util.Scanner;

public class while1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int i = 1;
        int x, k = 0, sanoq = 0;
        x = (int) (Math.random() * 100);
        System.out.println("sonni toping");
        while (x != k) {
            k = in.nextInt();
            sanoq++;
            if(x > k){
                System.out.println("Komputer oylagan son kattaroq");
            }
            else if(x < k){
                System.out.println("Komputer oylagan son kichikroq");
            }
        }
        System.out.println("Topdingiz!!!");
        System.out.println("siz " + sanoq + " urinishda topdingiz");


//        double s = 0;
//        while (i <= 10) {
//            System.out.println(i);
//            s+=i;
//            i++;
//        }
//        System.out.println(s);

//        do {
//            System.out.println(i);
//            i++;
//        }while(i<1);
//        while (i < 1){
//            System.out.println(i);
//            i++;
//        }
//        double s = 0;
//        do {
//            System.out.println(i);
//            s+=i;
//            i++;
//
//        }while (i<=10);
//        System.out.println(s);


    }
}
