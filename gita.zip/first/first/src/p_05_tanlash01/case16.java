package p_05_tanlash01;

import java.util.Scanner;

public class case16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("son kiriting ");
        int n = in.nextInt();
        int a = n % 10, b = n / 10;
        switch(b){
            case 1:
                System.out.print("O'n ");
                break;
            case 2:
                System.out.print("Yigirma ");
                break;
            case 3:
                System.out.print("O'ttiz ");
                break;
            case 4:
                System.out.print("Qirq ");
                break;
            case 5:
                System.out.print("Ellik ");
                break;
            case 6:
                System.out.print("Olmish ");
                break;
            default:
                System.out.print("Bunday son kiritmang ");
        }
        switch (a) {
            case 1:
                System.out.print("bir");
                break;
            case 2:
                System.out.print("ikki");
                break;
            case 3:
                System.out.print("uch");
                break;
            case 4:
                System.out.print("to'rt");
                break;
            case 5:
                System.out.print("besh");
                break;
            case 6:
                System.out.print("olti");
                break;
            case 7:
                System.out.print("yetti");
                break;
            case 8:
                System.out.print("sakkiz");
                break;
            case 9:
                System.out.print("to'qqiz");
                break;

        }

    }
}
