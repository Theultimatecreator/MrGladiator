package p_05_tanlash01;

import java.util.Scanner;

public class case14 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("var = ");
        int var = in.nextInt();
        double a = 0, R1 = 0, R2 = 0, S = 0;
        switch (var) {
            case 1: {
                System.out.println("tomoni a = ");
                a = in.nextDouble();
                R1 = a * Math.sqrt(3) / 6;
                R2 = 2 * R1;
                S = a * a * Math.sqrt(3) / 4;
                break;
            }
            case 2: {
                System.out.println("R2 = ");
                R2 = in.nextDouble();
                R1 = 2 / R2;
                a = Math.sqrt(3) / (6 * R1);
                S = a * a * Math.sqrt(3) / 4;
                break;
            }
            case 3: {
                System.out.println("S = ");
                S = in.nextDouble();
                a = Math.sqrt(Math.sqrt(3) / (6 * S));
                R1 = a * Math.sqrt(3) / 6;
                R2 = 2 * R1;
                break;
            }
        }
        System.out.println("tashqi radius = " + R2);
        System.out.println("Tomoni = " + a);
        System.out.println("yuza = " + S);
    }
}
