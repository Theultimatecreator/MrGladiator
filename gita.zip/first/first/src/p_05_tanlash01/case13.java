package p_05_tanlash01;

import java.util.Scanner;

public class case13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("raqam = ");
        int raqam = in.nextInt();
        double a = 0, c = 0, h = 0, S = 0;
        switch (raqam) {
            case 1: {
                System.out.print("a = ");
                a = in.nextDouble();
                c = a * Math.sqrt(2);
                h = c / 2;
                S = c * h / 2;
                break;
            }
            case 2: {
                System.out.print("c = ");
                c = in.nextDouble();
                a = c / Math.sqrt(2);
                h = c / 2;
                S = c * h / 2;
                break;
            }
            case 3: {
                System.out.print("h = ");
                h = in.nextDouble();
                c = h * 2;
                a = c / Math.sqrt(2);
                S = c * h / 2;
                break;
            }
            case 4: {
                System.out.println("S = ");
                S = in.nextDouble();
                c = 2 * Math.sqrt(S);
                a = c / Math.sqrt(2);
                h = c / 2;
                break;
            }

        }
        System.out.println("Katet = " + a);
        System.out.println("gipotinuza = " + c);
        System.out.println("Balandlik = " + h);
        System.out.println("yuza = " + S);
    }
}
