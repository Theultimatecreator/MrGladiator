package p_05_tanlash01;

import java.util.Scanner;

public class case12 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("raqam = ");
        int raqam = in.nextInt();
        double R = 0, D = 0, L = 0, S = 0, pi = 3.14;
        switch (raqam) {
            case 1 -> {
                System.out.print("R = ");
                R = in.nextDouble();
                D = 2 * R;
                L = 2 * pi * R;
                S = pi * R * R;
            }
            case 2 -> {
                System.out.print("D = ");
                D = in.nextDouble();
                R = D / 2;
                L = 2 * pi * R;
                S = pi * R * R;
            }
            case 3 -> {
                System.out.print("L = ");
                L = in.nextDouble();
                R = 2 * pi / L;
                D = 2 * R;
                S = pi * R * R;
            }
            case 4 -> {
                System.out.print("S = ");
                S = in.nextDouble();
                R = Math.sqrt(pi * S);
                D = 2 * R;
                L = 2 * pi * R;
            }
        }
        System.out.println("radius = " + R);
        System.out.println("diametr = " + D);
        System.out.println("uzunlik = " + L);
        System.out.println("yuza = " + S);
    }
}
