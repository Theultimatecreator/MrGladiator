package p_05_tanlash01;

import java.util.Scanner;

public class case1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();
        switch (n) {
            case 1:
                System.out.print("Dushanba");
                break;
            case 2:
                System.out.print("Seshanba");
                break;
            case 3:
                System.out.print("Chorshanba");
                break;
            case 4:
                System.out.print("Payshanba");
                break;
            case 5:
                System.out.print("Juma");
                break;
            case 6:
                System.out.print("Shanba");
                break;
            case 7:
                System.out.print("Yakshanba");
                break;
            default:
                System.out.print("Bunday son kiritish mumkin emas");
                break;
        }
    }
}
