package p_05_tanlash01;

import java.util.Scanner;

public class case15 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("birlik kiriting = ");
        int M = in.nextInt();
        System.out.print("O'nlik kiriting ");
        int N = in.nextInt();
        switch (N) {
            case 6:
                System.out.print("olti ");
                break;
            case 7:
                System.out.print("yetti ");
                break;
            case 8:
                System.out.print("sakkiz ");
                break;
            case 9:
                System.out.print("to'qqiz ");
                break;
            case 10:
                System.out.print("o'n ");
                break;
            case 11:
                System.out.print("valet ");
                break;
            case 12:
                System.out.print("dama ");
                break;
            case 13:
                System.out.print("qirol ");
                break;
            case 14:
                System.out.print("tuz ");
                break;
            default:
                System.out.print("Bunday qiymat kiritmang");
        }
        switch (M) {
            case 1:
                System.out.print("g'isht");
                break;
            case 2:
                System.out.print("olma");
                break;
            case 3:
                System.out.print("chillak");
                break;
            case 4:
                System.out.print("qarg'a");
                break;
        }

    }
}
