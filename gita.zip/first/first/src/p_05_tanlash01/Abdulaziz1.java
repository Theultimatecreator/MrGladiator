package p_05_tanlash01;

import java.util.Scanner;

public class Abdulaziz1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int d = in.nextInt();
        int m = in.nextInt();
        switch (d / 10) {
            case 1 -> System.out.print("1");
            case 2 -> System.out.print("2");
            case 3 -> System.out.print("3");
        }
        switch (d % 10) {
            case 1 -> System.out.print("1");
            case 2 -> System.out.print("2");
            case 3 -> System.out.print("3");
            case 4 -> System.out.print("4");
            case 5 -> System.out.print("5");
            case 6 -> System.out.print("6");
            case 7 -> System.out.print("7");
            case 8 -> System.out.print("8");
            case 9 -> System.out.print("9");
        }
        switch (m) {
            case 1 -> System.out.println("- yanvar");
            case 2 -> System.out.println("- fevral");
            case 3 -> System.out.println("- mart");
            case 4 -> System.out.println("- aprel");
            case 5 -> System.out.println("- may");
            case 6 -> System.out.println("- iyun");
            case 7 -> System.out.println("- iyul");
            case 8 -> System.out.println("- avgust");
            case 9 -> System.out.println("- sentabr");
            case 10 -> System.out.println("- oktabr");
            case 11 -> System.out.println("- noyabr");
            case 12 -> System.out.println("- dekabr");
        }
    }
}


class Abdulaziz2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("yo'nalish :");
        char y = in.next().charAt(0);
        System.out.println("Komanda: ");
        int k = in.nextInt();
        switch (y) {
            case 's' -> {
                System.out.println("shimol tomon");
                switch (k) {
                    case 0 -> System.out.println("harakatni davom ettir!!");
                    case 1 -> System.out.println("Chapga buril!!");
                    case 2 -> System.out.println("O'nga buril!!");
                }
            }
            case 'j' -> {
                System.out.println("Janub tomon");
                switch (k) {
                    case 0 -> System.out.println("harakatni davom ettir!!");
                    case 1 -> System.out.println("Chapga buril!!");
                    case 2 -> System.out.println("O'nga buril!!");
                }
            }
            case 'q' -> {
                System.out.println("sharq tomon");
                switch (k) {
                    case 0 -> System.out.println("harakatni davom ettir!!");
                    case 1 -> System.out.println("Chapga buril!!");
                    case 2 -> System.out.println("O'nga buril!!");
                }
            }
            case 'g' -> {
                System.out.println("Garb tomon");
                switch (k) {
                    case 0 -> System.out.println("harakatni davom ettir!!");
                    case 1 -> System.out.println("Chapga buril!!");
                    case 2 -> System.out.println("O'nga buril!!");
                }
            }
        }
    }
}


class Abdulaziz3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("son kiriting");
        int n = in.nextInt();
        double a = 0, s = 0, h = 0, c = 0;
        switch (n) {
            case 1 -> {
                System.out.println("Katetni kiriting");
                a = in.nextInt();
                c = a * Math.sqrt(2);
                h = c / 2;
                s = (c * h) / 2;
            }
            case 2 -> {
                System.out.println("gipotinuzani kiriting");
                c = in.nextInt();
                a = c / Math.sqrt(2);
                h = c / 2;
                s = (c * h) / 2;
            }
            case 3 -> {
                System.out.println("balandlikni kiriting");
                h = in.nextInt();
                c = h * 2;
                a = c / Math.sqrt(2);
                s = (c * h) / 2;
            }
            case 4 -> {
                System.out.println("yuzani kiriting");
                s = in.nextInt();
                c = 2 * Math.sqrt(s);
                a = c / Math.sqrt(2);
                h = c / 2;
            }
        }
        System.out.println("katet = " + a);
        System.out.println("gipotinuza = " + c);
        System.out.println("balandlik = " + h);
        System.out.println("yuza = " + s);
    }
}