import java.util.Scanner;

public class fibanachi {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a, b, c, n;
        System.out.print("a = ");
        a = in.nextInt();
        System.out.print("b = ");
        b = in.nextInt();
        System.out.print("n = ");
        n = in.nextInt();

        for (int i = 0; i <= 10; i++) {
            c = a + b;
            a = b;
            b = c;
            System.out.println("fibonachi:" + c);
            if (n == c) {
                System.out.println(n + "fibanachi sonalri orasida");
                break;
            }
            else{
                System.out.println(n +"Fibanachi sonlari orasida emas");
            }

        }

    }
}
