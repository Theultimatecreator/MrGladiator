package bonus_massiv;

import java.util.Scanner;

public class massiv_seven {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt(), s = 0;
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
            s += Math.pow(-1, i) * a[i];
        }
        System.out.println("s = " +s);
    }
}
