package bonus_massiv;

import java.util.Scanner;

public class massiv_four {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("n = ");
        int n = in.nextInt(), p = 1;
        int a[] = new int[n];
        System.out.println("n ta son kiriting ");
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
            p *= Math.abs(a[i]);
        }
        System.out.println("Massiv elementlari ko'paytmasi = " + p);

    }
}
