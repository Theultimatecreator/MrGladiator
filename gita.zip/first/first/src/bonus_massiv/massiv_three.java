package bonus_massiv;

import java.util.Scanner;

public class massiv_three {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Massiv elementlari sonini kiriting n = ");
        int n = in.nextInt(), s = 0;
        int a[] = new int[n];
        System.out.println("n ta butun son kiriting ");
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
            s += Math.abs(a[i]);
        }
        System.out.println("Massiv elementlari yigindisi = " + s);

    }
}
