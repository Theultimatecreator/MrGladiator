package bonus_massiv;

import java.util.Scanner;

public class massiv_eight {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("n = ");
        int n = scanner.nextInt();
        int a[] = new int[n];

        for (int i = 0; i < n; i++) {
            System.out.print((i + 1) + "-son = ");
            a[i] = scanner.nextInt();
            a[i] = 2 * i + 1;
        }

        float sum = 0;
        for (int i = 0; i < n; i++) {
            sum += Math.pow(-1, i) * (a[i] / fact(i));
        }

        System.out.println("Yig'indi = " + sum);
        }


        public static long fact(int n) {
            long s = 1;
            if (n == 0) return 1;
            for (int i = 1; i <= n; i++) {
                s *= i;
            }
            return s;


        }
}
