package Asilbek;

import java.util.Scanner;

public class case13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double a = 0, c = 0, h = 0, s = 0;
        switch (n) {
            case 1 -> {
                System.out.println("a = ");
                a = in.nextDouble();
                c = a * Math.sqrt(2);
                h = c / 2;
                s = h * c / 2;
            }
            case 2 -> {
                System.out.println("c = ");
                c = in.nextDouble();
                a = c / Math.sqrt(2);
                h = c / 2;
                s = h * c / 2;
            }
            case 3 -> {
                System.out.println("h = ");
                h = in.nextDouble();
                c = 2 * h;
                a = c / Math.sqrt(2);
                s = h * c / 2;
            }
            case 4 -> {
                System.out.println("s = ");
                s = in.nextDouble();
                s = h * c / 2;
                c = 2 * h;
                a = c / Math.sqrt(2);
            }
        }
    }
}
