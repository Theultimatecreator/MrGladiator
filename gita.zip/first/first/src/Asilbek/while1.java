package Asilbek;

import java.util.Scanner;

public class while1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        int b = in.nextInt();
        int r = a - b;
        int k = 1;
        while(r >= b){
            r-=b;
            k++;
        }
        System.out.println("joylashgan qismi = " + r);
        System.out.println("joylashgan qismi = " + k);
//        System.out.println("while");
//        int i = 1;
//        while(i <= n){
//            System.out.print(i);
//            i++;
//        }
//        System.out.println("for");
//
//        for (int j = 1; j <=n; j++) {
//            System.out.print(j);
//        }
//        System.out.println("do-while");
//        do {
//            System.out.println(i);
//            i++;
//        }while (i <= n);
    }
}
