package Asilbek;

import java.util.Scanner;

public class massiv90 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] a = new int[n];

        int t = 1;
        for (int i = 0; i < n; i++) {
            a[i] = t++;
            System.out.print(a[i] + " ");
        }
        System.out.println();
        System.out.println("k = ");
        int k = in.nextInt();
        for (int i = k; i < n - 1; i++) {
            a[i] = a[i + 1];
        }
        System.out.println("k - index kiritilgandan kn");
        for (int i = 0; i < a.length - 1; i++) {
            System.out.print(a[i] + " ");
        }
    }
}

class massiv92 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] a = new int[n];

        int t = 1;
        for (int i = 0; i < n; i++) {
            a[i] = t++;
            System.out.print(a[i] + " ");
        }
        System.out.println();
        int k = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i] % 2 == 0) {
                a[k] = a[i];
                k++;
            }
        }
        System.out.println("soni = " + k);
        for (int i = 0; i < k; i++) {
            System.out.print(a[i] + " ");
        }
    }
}

class massiv94 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        int t = 1;
        for (int i = 0; i < n; i++) {
            a[i] = t++;
            System.out.print(a[i] + " ");
        }
        System.out.println();
        int k = 0;
        for (int i = 0; i < a.length; i += 2) {
            a[k] = a[i];
            k++;
        }
        System.out.println("soni =" + k);
        for (int i = 0; i < k; i++) {
            System.out.print(a[i]);
        }

    }
}

class massiv95 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
//        int t=1;
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        System.out.println();
        int k = 0;
        for (int i = 1; i < a.length; i++) {
            if (a[k] != a[i])
                a[++k] = a[i];
        }
        for (int i = 0; i <= k; i++) {
            System.out.print(a[i] + " ");
        }

    }
}

class massiv101{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n=in.nextInt();
        int a[]=new int[n + 1];
        int t=1;
        for (int i = 0; i < n; i++) {
            a[i]=t++;
            System.out.print(a[i] +" ");
        }
        System.out.println();
        int k=in.nextInt();
        for (int i = n; i > k; i--) {
            a[i] = a[i - 1];
        }
        a[k] = 0;
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }

    }
}