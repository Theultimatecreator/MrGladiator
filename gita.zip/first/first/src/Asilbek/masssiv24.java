package Asilbek;

import java.util.Scanner;

public class masssiv24 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        int d = a[1] - a[0];
        boolean t = true;
        for (int i = 2; i < n; i++) {
            if (a[i] - a[i - 1] != d) {
                t = false;
                break;
            }
        }
        if (t) System.out.println(d);
        else
            System.out.println(0);
    }
}

class massiv37 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        int k = 0;
        for (int i = 1; i < a.length; i++) {
            if (a[i] > a[i - 1])
                k++;
        }
        System.out.println(k);
    }
}

class massiv51 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        int b[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        for (int i = 0; i < n; i++) {
            b[i] = in.nextInt();
            int m = a[i];
            a[i] = b[i];
            b[i] = m;
        }
        for (int i = 0; i < n; i++) {
            System.out.print(a[i] + " ");
        }
        System.out.println();
        for (int i = 0; i < n; i++) {
            System.out.print(b[i] + " ");
        }

    }
}

class massiv58 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        int b[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        int summ = 0;
        for (int i = 0; i < n; i++) {
            summ += a[i];
            b[i] = summ;
            System.out.print(b[i] + " ");
        }
    }
}