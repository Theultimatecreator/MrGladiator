package Asilbek;

import java.util.Scanner;

public class massiv97 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        int k = n - 1;
        boolean bull;
        for (int i = n - 1; i >= 0; i--) {
            bull = true;
            for (int j = n - 1; j > k; j--) {
                if (a[i] == a[j]) {
                    bull = false;
                    break;
                }
            }
            if (bull) {
                a[k--] = a[i];
                System.out.print(i + " ");
            }
        }
        System.out.println();
        for (int i = k + 1; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
    }
}

class massiv98 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        int b[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        int k = 0;
        int count;
        for (int i = 0; i < a.length; i++) {
            count = 0;
            for (int j = 0; j < a.length; j++) {
                if (a[i] == a[j]) {
                    ++count;
                }
            }
            if (count < 3) {
                b[k++] = a[i];
            }
        }
        System.out.println("soni " + k + " ta ");
        for (int i = 0; i < k; i++) {
            System.out.print(b[i] + " ");
        }
    }
}

//massiv elementlarini saralash
class bubleSort {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        boolean isSorted = false;

        while (!isSorted) {
            isSorted = true;
            for (int i = 1; i < a.length; i++) {
                if (a[i] < a[i - 1]) {
                    int temp = a[i];
                    a[i] = a[i - 1];
                    a[i - 1] = temp;
                    isSorted = false;
                }
            }
        }
        for (int element : a) {
            System.out.print(element + " ");
        }
    }
}
