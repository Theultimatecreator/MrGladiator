package Asilbek;

import java.util.Scanner;

public class methods {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a = in.nextDouble();
        double b = in.nextDouble();
        int k = in.nextInt();
        int q = in.nextInt();

        System.out.println(asilbek(a, b));
        salihov(k, q);
    }

    public static double asilbek(double a, double b) {
        if (a > b)
            return a;
        return b;
    }

    public static void salihov(int a, int b) {
        if (a > b) {
            System.out.println(a + " > " + b);
        } else if (a < b) {
            System.out.println(a + " < " + b);
        } else {
            System.out.println(a + " = " + b);
        }
    }
}
