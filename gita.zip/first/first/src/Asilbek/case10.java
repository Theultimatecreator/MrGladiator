package Asilbek;

import java.util.Scanner;

public class case10 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        char tomon = in.next().charAt(0);
        switch (tomon) {
            case 's' -> {
                System.out.println("siz shimolga burildingiz raqam tanlang!");
                int komand = in.nextInt();
                switch (komand) {
                    case 0 -> System.out.println("harakatni davomni davom ettir");
                    case 1 -> System.out.println("chapga buril");
                    case 2 -> System.out.println("o'nga buril");
                }
            }
            case 'j' -> {
                System.out.println("siz janubga burildingiz raqam tanlang!");
                int komand = in.nextInt();
                switch (komand) {
                    case 0 -> System.out.println("harakatni davomni davom ettir");
                    case 1 -> System.out.println("chapga buril");
                    case 2 -> System.out.println("o'nga buril");
                }
            }
            case 'q' -> {
                System.out.println("siz sharqqa burildingiz raqam tanlang!");
                int komand = in.nextInt();
                switch (komand) {
                    case 0 -> System.out.println("harakatni davomni davom ettir");
                    case 1 -> System.out.println("chapga buril");
                    case 2 -> System.out.println("o'nga buril");
                }
            }
            case 'g' -> {
                System.out.println("siz g'arbga burildingiz raqam tanlang!");
                int komand = in.nextInt();
                switch (komand) {
                    case 0 -> System.out.println("harakatni davomni davom ettir");
                    case 1 -> System.out.println("chapga buril");
                    case 2 -> System.out.println("o'nga buril");
                }
            }
        }
    }
}
