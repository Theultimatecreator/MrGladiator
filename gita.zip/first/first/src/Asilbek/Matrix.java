package Asilbek;

import java.util.Scanner;

public class Matrix {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr:");
        int m = in.nextInt();
        System.out.println("ustun:");
        int n = in.nextInt();
        int a[][] = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = j * 5;
            }
        }
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }

    }
}

class matrix3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr:");
        int m = in.nextInt();
        System.out.println("ustun:");
        int n = in.nextInt();
        int a[][] = new int[m][n];
        for (int i = 0; i < n; i++) {
            int c = in.nextInt();
            for (int j = 0; j < m; j++) {
                a[j][i] = c;
            }
        }
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }
    }
}

class matrix4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr:");
        int m = in.nextInt();
        System.out.println("ustun:");
        int n = in.nextInt();
        int a[][] = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = in.nextInt();
            }
        }
        System.out.println("k ni kiriting");
        int k = in.nextInt();
        for (int i = 0; i < n; i++) {
                System.out.print(a[k][i] + " ");
            }

    }
}