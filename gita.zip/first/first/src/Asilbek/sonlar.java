package Asilbek;

import java.util.Scanner;

public class sonlar {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        System.out.println(isPolendrom(n));

    }

    public static boolean isPolendrom(int m) {
        int sum = 0, num = m;
        while (num > 0) {
            sum = sum * 10 + num % 10;
            num /= 10;
        }
        return m == sum;
    }
}
