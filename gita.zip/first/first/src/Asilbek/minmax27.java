package Asilbek;

import java.util.Scanner;

public class minmax27 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
//        11111000000
        int k = 0, count = 0, index = 0, index2 = 0;
        for (int i = 1; i <= n; i++) {
            int num2 = in.nextInt();
            if (num2 == 1) {
                k++;
                if (count < k) {
                    count = k;
                    index = index2;
                }
            } else {
                k= 0;
                index2 = i;
            }
        }
        System.out.println((1+index)+ " " + count);
    }
}
