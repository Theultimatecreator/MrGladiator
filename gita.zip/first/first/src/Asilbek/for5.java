package Asilbek;

import java.util.Scanner;

public class for5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        int b = in.nextInt();
        int p = 1;
        for (int i = a; i <= b; i++) {
            p*=i;
        }
        System.out.println("summa = " +p);
    }
}
