package Asilbek;

import java.util.Scanner;

public class massiv1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        for (int i = 1; i < n; i += 2) {
            System.out.print(a[i] + " ");
        }
        for (int i = n - 2; i >= 0; i -= 2) {
            System.out.print(a[i] + " ");
        }
    }
}

class massiv16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        int t = n - 1;
        int k = 0;
        for (int i = 0; i < n; i++) {
            if (i % 2 == 0)
                System.out.print(a[k++] + " ");
            else
                System.out.print(a[t--] + " ");
        }
    }
}

class massiv17 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        int t = n - 1;
        int k = 0;
        for (int i = 0; i < n; i++) {
            if (i % 4 < 2)
                System.out.print(a[k++] + " ");
            else
                System.out.print(a[t--] + " ");
        }
    }
}

class massiv18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        int index = 0;
        for (int i = 0; i < n; i++) {
            if (a[i] < a[n - 1]) {
                index = a[i];
                break;
            }
        }
        System.out.println(index);
    }
}

class massiv19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        int index = 0;
        for (int i = 0; i < n; i++) {
            if (a[i] > a[0] && a[i] < a[n - 1])
                index = i;
        }
        System.out.println(index);
    }
}

class massiv20 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int k = in.nextInt();
        int l = in.nextInt();
        int p = 0;
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        for (int i = k + 1; i < l; i++) {
            p += a[i];
        }
        System.out.println(p);

    }
}