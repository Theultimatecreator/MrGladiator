package Asilbek;

import java.util.Scanner;

public class matrix19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int m = in.nextInt();
        int n = in.nextInt();
        int a[][] = new int[m][n];
        int t = 1;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = t++;
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }
        for (int i = 0; i < m; i++) {
            int sum = 0;
            int p = 1;
            for (int j = 0; j < n; j++) {
                sum += a[i][j];
                p *= a[i][j];
            }
            System.out.println((i + 1) + " -satr sum" + sum);
            System.out.println((i + 1) + " -satr p" + p);
        }

    }
}
