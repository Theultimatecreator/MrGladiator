package Asilbek;

import java.util.Scanner;

public class shart1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        int b = in.nextInt();
        int c = in.nextInt();
        int sanoq = 0;
        if (a > 0) sanoq++;
        if (b > 0) sanoq++;
        if (c > 0) sanoq++;
        System.out.println(sanoq);

//        !=   > < >= <= == && ||
//        if (m > n) {
//            System.out.println("m katta n dan");
//        } else if (n > m) {
//            System.out.println("n katta m dan");
//        } else {
//            System.out.println("ikkalasi teng");
//        }


    }
}
