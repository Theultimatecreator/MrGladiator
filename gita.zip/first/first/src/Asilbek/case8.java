package Asilbek;

import java.util.Scanner;

public class case8 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int day = in.nextInt();
        int month = in.nextInt();
        switch (day / 10) {
            case 1 -> System.out.print("1");
            case 2 -> System.out.print("2");
            case 3 -> System.out.print("3");
        }
        switch (day % 10) {
            case 0 -> System.out.print("0 ");
            case 1 -> System.out.print("1 ");
            case 2 -> System.out.print("2 ");
            case 3 -> System.out.print("3 ");
            case 4 -> System.out.print("4 ");
            case 5 -> System.out.print("5 ");
            case 6 -> System.out.print("6 ");
            case 7 -> System.out.print("7 ");
            case 8 -> System.out.print("8 ");
            case 9 -> System.out.print("9 ");
        }
        switch (month) {
            case 1 -> System.out.print("-yanvar");
            case 2 -> System.out.print("-fevral");
            case 3 -> System.out.print("-mart");
            case 4 -> System.out.print("-aprel");
            case 5 -> System.out.print("-may");
        }
    }
}
