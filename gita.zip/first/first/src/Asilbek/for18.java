package Asilbek;

import java.util.Scanner;

public class for18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double a = in.nextDouble();
        double s = 0;
        int p = 1;
        int sign = 1;
        for (int i = 1; i <= n; i++) {
            s += Math.pow(-1, i) * Math.pow(a, i);
        }
        System.out.println(s);
    }
}

class for19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int p = 1;
        for (int i = 1; i <= n; i++) {
            p *= i;
        }
        System.out.println(" p = " + p);
    }
}

class for31 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double a0 = 2;
        double ak;
        for (int i = 1; i <= n; i++) {
            ak = 2 + 1 / a0;
            a0 = ak;
            System.out.println(ak);
        }
    }
}

class for33 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
//        1 1 2 3 5 8
        int n = in.nextInt();
        int f1 = 1;
        int f2 = 1;
        System.out.println(f1 + "\n" + f2);
        int f3;
        for (int i = 3; i <= n; i++) {
            f3 = f1 + f2;
            f1 = f2;
            f2 = f3;
            System.out.println(f3);
        }
    }
}

class inner1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                if (j % 2 == 0 && i % 2 == 1 || j % 2 == 1 && i % 2 == 0)
                    System.out.print("[*]");
                else
                    System.out.print("[ ]");
            }
            System.out.println();
        }
    }
}