package Asilbek;

import java.util.Scanner;

public class matrix13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int arr[][] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int m = 3;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m - i; j++) {
                System.out.print(arr[i][j] + " ");
            }
            for (int j = i + 1; j < m; j++) {
                System.out.print(arr[j][m - 1 - i] + " ");
            }
        }
    }
}
