package Asilbek;

import java.util.Scanner;

public class Case1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String s1 = in.next();
        String s2 = in.next();
        if (s1.length() > s2.length()) {
            for (int i = 0; i < s1.length() - s2.length(); i++) {
                s2 = "0" + s2;
                System.out.println(s2);
            }
        }
        else {
            for (int i = 0; i < s2.length() - s1.length(); i++) {
                s1 = "0" + s1;
                System.out.println(s1);
            }
        }
//        System.out.println(s1);
//        System.out.println(s2);
        String ans = "";
        int i = s1.length() - 1, d = 0;
        while (i >= 0) {
            int x = ((s1.charAt(i) - '0') + (s2.charAt(i) - '0') + d) % 10;
            d = ((s1.charAt(i) - '0') + (s2.charAt(i) - '0')) / 10;
            ans = Character.toString(x + '0') + ans;
            i--;
        }
        if (d > 0) {
            ans = Character.toString(d + '0') + ans;
        }
        System.out.println(ans);
    }
}
