package Asilbek.Matrixxx;

import java.util.Scanner;

public class matrix20 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int m = in.nextInt();
        int n = in.nextInt();
        int a[][] = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = in.nextInt();
            }
        }
        for (int i = 0; i < m; i++) {
            int min = a[i][0];
            for (int j = 1; j < n; j++) {
                if (a[i][j] < min) {
                    min = a[i][j];
                }
            }
            System.out.println((i + 1) + " - satr: " + min);
        }

    }
}
