package Asilbek;

import java.util.Scanner;

public class massivLesson {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        a[0] = 2;
        for (int i = 1; i < n; i++) {
            a[i] = a[i-1] * 2;
            System.out.print("a["+i + "] = "+a[i] + " ");
        }
//        a[3] = 20;
//        for (int i = 0; i < n; i++) {
//
//            System.out.print("a["+i + "] = "+a[i] + " ");
//        }
    }
}
