package Asilbek;

import java.util.Scanner;

public class minmax1 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int min = in.nextInt();
        int max = min;
        for (int i = 1; i < n; i++) {
            int a = in.nextInt();
            if (min > a) {
                min = a;
            }
            if (max < a) {
                max = a;
            }

        }
        System.out.println(max);
        System.out.println(min);
    }
}


class minmax2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a = in.nextInt();
        int b = in.nextInt();
        int minS = a * b;
        for (int i = 1; i < n; i++) {
            int c = in.nextInt();
            int d = in.nextInt();
            int S = c * d;
            if (minS > S) {
                minS = S;
            }
        }
        System.out.println(minS);
    }
}