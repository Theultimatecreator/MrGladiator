package Asilbek;

import java.util.Scanner;

public class minmax14 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int b = in.nextInt();
        int min = in.nextInt();
        int index = 0;
        for (int i = 2; i < 10; i++) {
            int a = in.nextInt();
            if (min < b) {
                min = b;
            }
            if (a > b) {
                if (a < min) {
                    min = a;
                    index = i;
                }
            }
        }
        if (index == 0) {
            System.out.println("00");
        } else {
            System.out.println(index);
        }
    }
}
