package Asilbek;

import java.util.Scanner;

public class case15 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
//        1-g'isht 2-olma  3-chillak  4 qarg'a
        System.out.println("n = karta qiymati");
        int n = in.nextInt();
        System.out.println("m karta turi");
        int m = in.nextInt();
        switch (n){
            case 6-> System.out.print("olti ");
            case 7-> System.out.print("yetti ");
            case 8-> System.out.print("sakkiz ");
            case 9-> System.out.print("to'qqiz ");
            case 10-> System.out.print("o'n ");
            case 11-> System.out.print("valet ");
            case 12-> System.out.print("dama ");
            case 13-> System.out.print("qirol ");
            case 14-> System.out.print("tuz ");
        }
        switch (m){
            case 1-> System.out.println(" g'isht");
            case 2-> System.out.println(" olma");
            case 3-> System.out.println(" chillak");
            case 4-> System.out.println(" qarg'a");
        }

    }
}
