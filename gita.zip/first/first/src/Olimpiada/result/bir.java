package Olimpiada.result;

import java.util.Arrays;
import java.util.Scanner;

public class bir {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int [] arr = new int[n];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = in.nextInt();
        }
        String no = "";
        for (int i = 0; i < arr.length; i++) {
            int num_e = 0;
            int e = arr[i];
            for (int j = 0; j < arr.length; j++) {
                if(arr[j] == e){
                    num_e ++;
                }
            }
            if(num_e != 2){
                no += arr[i] +" ";
            }
        }
        System.out.println(no);
    }
}
