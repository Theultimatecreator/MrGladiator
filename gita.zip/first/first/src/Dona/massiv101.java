package Dona;

import java.util.Scanner;

public class massiv101 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int k = in.nextInt();
        int a[] = new int[n + 1];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        for (int i = n; i > k; i--) {
            a[i] = a[i - 1];
        }
        a[k] = 0;
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
    }
}
