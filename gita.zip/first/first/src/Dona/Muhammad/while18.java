package Dona.Muhammad;

import java.util.Scanner;

public class while18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();

    }
}
