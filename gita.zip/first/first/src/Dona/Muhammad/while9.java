package Dona.Muhammad;

import java.util.Scanner;

public class while9 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int k = 0;
        int daraja = 1;
        while (daraja <= n) {
            daraja *= 3;
            k++;
        }
        System.out.println(k - 1);
    }
}

class while15 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double sum = in.nextDouble();
        int p = in.nextInt();
        int k = 0;
        double a = sum * 2;
        while (sum < a) {
            k++;
            sum = sum * p / 100 + sum;

        }
        System.out.println(k + " oyda");
        System.out.println(sum + " so'm bo'ladi");

    }
}