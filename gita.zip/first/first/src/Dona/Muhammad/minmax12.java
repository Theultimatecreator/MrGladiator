package Dona.Muhammad;

import java.util.Scanner;

public class minmax12 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int min = in.nextInt();
        for (int i = 2; i < n; i++) {
            int a = in.nextInt();
            if (min < 0){
                min = a;
                continue;
            }
            if (min > a && a > 0){
                min = a;
            }
        }
        if (min < 0){
            System.out.println(0);
        }else
            System.out.println(min);
    }
}
