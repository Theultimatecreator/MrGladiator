package Dona.Muhammad;

import java.util.Scanner;

public class minmax6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int min = in.nextInt();
        int max = min;
        int indexmin = 1;
        int indexmax = 1;
        for (int i = 2; i <= n; i++) {
            int a = in.nextInt();
            if (min > a) {
                min = a;
                indexmin = i;
            }
            if (max <= a) {
                max = a;
                indexmax = i;
            }
        }
        System.out.println("birinchi uchraga min element № " + indexmin);
        System.out.println("oxirgi uchraga max element № " + indexmax);
    }
}
