package Dona.Muhammad;

public class whileLoop1 {
    public static void main(String[] args) {

        int a = 7;
        int b = 3;
        int r = a - b;//7-3=4  4 - 3 =1
        while (r >= b) {
            r -= b;
        }
        System.out.println("qoldiq qism = " + r);

        //while do-while
//        int i = 1;
//        int s = 0;
//        while (i <= 10){
//            i++;
//            System.out.println(i);
//            s+=i;
//        }
//        System.out.println(s);

//        while faqat true qiymat bolganda siklni ichiga kiradi
//        while (i < 10){
//            System.out.println(i);
//            i++;
//        }

//        do {
//            System.out.println(i);
//            i++;
//        }while (i>10);
    }
}
