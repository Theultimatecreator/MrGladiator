package Dona.Muhammad;

import java.util.Scanner;

public class minmaxLesson {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int min = in.nextInt();
        int max = min;
        for (int i = 1; i < n; i++) {
            int a = in.nextInt();
            if (min > a){
                min = a;
            }
            if (max < a){
                max = a;
            }
        }
        System.out.println("max = " + max);
        System.out.println("min = " + min);
    }
}

class minmax2{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a = in.nextInt();
        int b = in.nextInt();
        int s1 = a * b;
        for (int i = 0; i < n; i++) {
            int c = in.nextInt();
            int d = in.nextInt();
            int s2 = c * d;
            if (s1 > s2){
                s1 = s2;
            }

        }
        System.out.println("eng kichik yuza = " + s1);
    }
}
