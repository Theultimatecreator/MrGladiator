package Dona.Muhammad.Masivlar;

import java.util.Scanner;

public class array1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        a[0] = 2;
        for (int i = 1; i < n; i++) {
            a[i] = a[i - 1] * 2;
//            System.out.print(a[i] + " ");
        }
        for (int i = 0; i < n; i++) {
            System.out.print("a[" + i + "] = " + a[i] + " ");
        }
    }
}
class massiv5{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        a[0] = 1;
        a[1] = 1;
        a[2] = a[0] + a[1];
        System.out.print(a[0] + " " + a[1] + " " + a[2] + " ");
        for (int i = 3; i < n; i++) {
            a[i] = a[i - 1] + a[i - 2];
            System.out.print(a[i] + " ");
        }
    }
}