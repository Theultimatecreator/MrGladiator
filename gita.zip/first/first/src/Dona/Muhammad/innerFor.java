package Dona.Muhammad;

import java.util.Scanner;

public class innerFor {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
//        int n = in.n  extInt();
        for (int i = 1; i <= 8; i++) {
            for (int j = 1; j <= 8; j++) {
                if (i == 1 || j == 1 || i == 8 || j == 8 || i == j) {
                    System.out.print("[+]");
                } else {
                    System.out.print("[ ]");
                }
            }
            System.out.println();
        }
    }
}


class inner2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int count = 1;
        for (int i = n; i > 0; i--) {
            for (int j = i; j < n + 1; j++) {
                System.out.print("\t" + count);
                count++;
            }
            System.out.println();
        }
    }
}


class inner3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print("*" + " ");

            }
            System.out.println();
        }
    }
}

