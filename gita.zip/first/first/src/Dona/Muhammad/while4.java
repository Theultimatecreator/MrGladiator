package Dona.Muhammad;

import java.util.Scanner;

public class while4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int daraja = 1;
        while (daraja < n) {
            daraja *= 3;
        }
        if (daraja == n) {
            System.out.println("3 ning darajasi ");
        } else {
            System.out.println("uchning darajasi emas");
        }
    }
}


class while5{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int daraja = 1;
        int k = 0;
        while (daraja < n){
            daraja *= 2;
            k++;
        }
        if (daraja == n){
            System.out.println(k + " -  darajasi");
        }else{
            System.out.println("dajasi emas");
        }
    }
}

class while6{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int p = 1;
        while (n > 0){
            p*=n;
            n-=2;
        }
        System.out.println(p);
    }
}

class while7{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int k = 1;

        while (k * k < n){
            k++;
        }
        System.out.println(k);
    }
}