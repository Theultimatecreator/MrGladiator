package Dona.Muhammad.method;

import java.util.Scanner;

public class fun4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        System.out.println(daraja(n));
    }
    public static int daraja(int a){
        return a * a;
    }
}
