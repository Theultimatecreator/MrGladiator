package Dona.Muhammad.method;

import java.util.Scanner;

public class fun1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a = in.nextDouble();
        double b = in.nextDouble();
        double c = in.nextDouble();
        int d = in.nextInt();
        int e = in.nextInt();
        powerA3(a);
        powerA3(b);
        powerA3(c);
        powerA3(d);
        powerA3(e);
    }

    public static void powerA3(double a) {
        double t = a * a * a;
        System.out.println(t);
    }
    public static void powerA3(int a){
        int k = a * a * a;
        System.out.println(k);
    }
}
