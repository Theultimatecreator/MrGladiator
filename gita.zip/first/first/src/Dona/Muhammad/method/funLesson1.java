package Dona.Muhammad.method;

import java.util.Scanner;

public class funLesson1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int k = in.nextInt();
        int r = in.nextInt();
        addLeftDigit(k, r);
    }

    public static void addLeftDigit(int k, int r) {
        int n = k;
        while (k > 0) {
            k /= 10;
            r *= 10;
        }
        n += r;
        System.out.println("natija = " + n);
    }
}

class fun10 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        int b = in.nextInt();
        int c = in.nextInt();
        int d = in.nextInt();
        swap(a, b);
        swap(c, d);

    }

    public static void swap(int a, int b) {
        int k = a;
        a = b;
        b = k;
        System.out.println(a);
        System.out.println(b);
    }
}

class robo {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int k = in.nextInt();
        System.out.println((n * k) + 1);
    }
}

class fun22 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a = in.nextDouble();
        double b = in.nextDouble();
        byte n = in.nextByte();
        calc(a, b, n);
    }

    public static void calc(double a, double b, byte op) {
        double sum = 0;
        switch (op) {
            case 1 -> sum = a - b;
            case 2 -> sum = a * b;
            case 3 -> sum = a / b;
            default -> sum = a + b;
        }
        System.out.println("natija = " + sum);
    }
}

class fun25{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a = in.nextInt();
        int b = in.nextInt();
        System.out.println(isSquare(n));
        System.out.println(isSquare(a));
        System.out.println(isSquare(b));

    }
    public static boolean isSquare(int k){
        double d = Math.sqrt(k);
        return Math.floor(d)==d;
    }
}