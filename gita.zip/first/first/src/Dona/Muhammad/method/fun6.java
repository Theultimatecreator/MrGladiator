package Dona.Muhammad.method;

import java.util.Scanner;

public class fun6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        int b = in.nextInt();
        int c = in.nextInt();
        digitCountSum(a);
        digitCountSum(b);
        digitCountSum(c);
    }

    public static void digitCountSum(int a) {
        int sum = 0;
        int count = 0;
        while (a > 0) {
            count++;
            sum += a % 10;
            a /= 10;
        }
        System.out.println("soni = " + count);
        System.out.println("summ = " + sum);
    }
}
