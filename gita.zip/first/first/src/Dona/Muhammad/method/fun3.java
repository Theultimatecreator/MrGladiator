package Dona.Muhammad.method;

import javax.imageio.ImageTranscoder;
import java.util.Scanner;

public class fun3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a = in.nextDouble();
        double b = in.nextDouble();
        double c = in.nextDouble();
        int d = in.nextInt();
        int e = in.nextInt();
        powerA3(a, b);
        powerA3(b, c);
        powerA3(c, d);
        powerA3(d, b);
        powerA3(e, a);
    }

    public static void powerA3(double a, double b) {
        double t = (a + b) / 2;
        double k = Math.sqrt(a * b);
        System.out.println(t);
        System.out.println(k);
    }

}
