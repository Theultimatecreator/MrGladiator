package Dona.Inher;

public class PhpTeacher extends Teacher {
    public PhpTeacher() {
        this.name = "Malika";
        this.age = 56;
        this.course = "PHP";
        this.workExperience = 19;
        this.surname = "Bahorova";
    }

    public void whatdo() {
        System.out.println("PHP dan dars beradi!");
    }
}
