package Dona.Inher;

public class Main {
    public static void main(String[] args) {
        JavaTeacher javaTeacher = new JavaTeacher();
        PhpTeacher phpTeacher = new PhpTeacher();
        javaTeacher.show();
        javaTeacher.whatDo();
        phpTeacher.show();
        phpTeacher.whatdo();
    }
}
