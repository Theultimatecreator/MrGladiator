package Dona.Inher;

public class JavaTeacher extends Teacher {
    public JavaTeacher() {
        this.name = "Dono";
        this.age = 26;
        this.course = "Java";
        this.workExperience = 9;
        this.surname = "Xo'janazarova";
    }

    public void whatDo() {
        System.out.println("javadan dars beradi!!");
    }
}
