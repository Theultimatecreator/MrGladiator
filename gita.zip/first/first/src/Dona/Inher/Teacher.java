package Dona.Inher;

public class Teacher {
    int age;
    String name;
    String surname;
    String course;
    int workExperience;
    public void show(){
        System.out.println("age = " + this.age);
        System.out.println("name = " + this.name);
        System.out.println("surname = " + this.surname);
        System.out.println("course = " + this.course);
        System.out.println("workExperience = " + this.workExperience);
    }
}
