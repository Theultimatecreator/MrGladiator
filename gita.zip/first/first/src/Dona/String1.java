package Dona;

import java.util.Scanner;

public class String1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("n1");
        int n1 = in.nextInt();
        System.out.println("n2");
        int n2 = in.nextInt();
        System.out.println("str1");
        String s1 = in.next();
        System.out.println("str2");
        String s2 = in.next();
        String newString = "";
        newString += s1.substring(0, n1);
        newString += s2.substring(s2.length() - n2);
        System.out.println(newString);
    }
}

class string2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        char c = in.next().charAt(0);
        String s = in.next();
        String temp = "";
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == c) {
                temp += s.charAt(i) + "" + s.charAt(i);
            } else {
                temp += s.charAt(i);
            }
        }
        s = temp;
        System.out.println(s);
    }
}

class str29 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        char c = in.next().charAt(0);
        System.out.println("s1");
        String s1 = in.next();
        System.out.println("s2");
        String s2 = in.next();
        s1 = s1.replace(c + "", s2 + c);
        System.out.println(s1);
    }
}

class str33 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String s1 = in.next();
        String s2 = in.next();
        s1 = s1.replaceAll(s2, "");
        System.out.println(s1);
    }
}

class str34 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String s1 = in.next();
        String s2 = in.next();
        int n = s1.lastIndexOf(s2);
        s1 = s1.substring(0, n) + s1.substring(n + s2.length());
        System.out.println(s1);
    }
}

class str40 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str1 = in.nextLine();
        int n = str1.indexOf(" ");
        int m = str1.lastIndexOf(" ");
        if (m != n) n++;
        str1 = str1.substring(n, m);
        System.out.println(str1);

    }
}