package Dona;

import java.util.Scanner;

public class massiv28 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] a = new int[n];
        int min = a[0], index = 0;
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
            if (i % 2 == 0) {
                if (min > a[i]) {
                    min = a[i];
                    index = i;
                }
            }
        }
        System.out.println(min + " " + index);

    }
}
