package Dona;

import java.util.Scanner;

public class booleancha1 {
    public static void main(String[] args) {
//        mantiqiy toifa boolean bn amalaga oshiriladi
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        boolean natija = a % 2 == 0;
        System.out.println(natija);
    }
}
