package Dona;

import java.util.Scanner;

public class lessonChar {
    public static void main(String[] args) {
//        int double float boolean
//        short long byte char String
//        char 2 bayt 16 bit
//        char dono = 'A';
//        System.out.println((int)dono);
//        char dono1 = 'a';
//        System.out.println((int)dono1);
//        char dono2 = in.next().charAt(0);
//        System.out.println((int)dono2);
        Scanner in = new Scanner(System.in);

        int a = in.nextInt();
        char c = in.next().charAt(0);
        int b = in.nextInt();
        if (c == '-') {
            System.out.println(a - b);

        }

//        String str = in.nextLine();
//        String str2 = in.nextLine();
//        System.out.println(str);
//        str += " Dasturchi";
//        System.out.println(str);
//        str2 = str2.concat(" " + str + " ");
//        System.out.println(str2 + " ");
    }
}
