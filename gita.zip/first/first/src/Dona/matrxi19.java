package Dona;

import java.util.Scanner;

public class matrxi19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int m = in.nextInt();
        int n = in.nextInt();
        int a[][] = new int[m][n];
        int t = 1;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = t++;
                System.out.print(a[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println();
        for (int i = 0; i < m; i++) {
            int summ = 0;
            for (int j = 0; j < n; j++) {
                summ += a[i][j];
            }
            System.out.println((i + 1) + " - satr : " + summ);
        }
    }
}
