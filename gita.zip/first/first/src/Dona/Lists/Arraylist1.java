package Dona.Lists;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class Arraylist1 {
    public static void main(String[] args) {
        ArrayList<String> cars = new ArrayList<>();
        cars.add("Spark");
        cars.add("Malibu");
        cars.add("Mavluda");
        cars.add("Gulsara");
        cars.add("Damas");
        cars.add("Napis");
        System.out.println(cars);
        System.out.println(cars.get(0));
        System.out.println(cars.remove(3));
        System.out.println(cars);
        cars.set(3, "Tico");
        System.out.println(cars);
        cars.add("Nexia");
        System.out.println(cars);

    }
}

class arraylist2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        ArrayList<String> fruit = new ArrayList<>();
        int n = in.nextInt();
        for (int i = 0; i < n; i++) {
            fruit.add(in.next());
        }
        System.out.println(fruit);
        for (int i = 0; i < fruit.size(); i++) {
            System.out.print(fruit.get(i) + " ");
        }
    }
}


class arraylistInteger {
    public static void main(String[] args) {
        ArrayList<Integer> myNumbers = new ArrayList<Integer>();
        myNumbers.add(10);
        myNumbers.add(15);
        myNumbers.add(20);
        myNumbers.add(25);
        myNumbers.add(20);

        for (int i = 0; i < myNumbers.size(); i++) {
            if (myNumbers.get(i) == 20) {
                myNumbers.remove(i);
                i--;
            }
        }
        System.out.print(myNumbers + " ");
    }
}

class collections1 {
    public static void main(String[] args) {
        ArrayList<Integer> myNumbers = new ArrayList<Integer>();
        myNumbers.add(10);
        myNumbers.add(15);
        myNumbers.add(20);
        myNumbers.add(25);
        myNumbers.add(20);
        Collections.sort(myNumbers);
        for (int element : myNumbers) {
            System.out.print(element + " ");
        }
    }
}

class linkedList1 {
    public static void main(String[] args) {
        LinkedList<String> cars = new LinkedList<>();
        cars.add("Muhammad");
        cars.add("Muhammad");
        cars.add("Muhammad");
        cars.add("Muhammad");
        cars.addFirst("Dono");
        cars.addLast("Dono");
        System.out.println(cars);
        System.out.println("remove");
        cars.removeFirst();
        System.out.println(cars);
        cars.removeLast();
        System.out.println(cars);
        System.out.println(cars.getFirst());
        System.out.println(cars.getLast());
    }
}