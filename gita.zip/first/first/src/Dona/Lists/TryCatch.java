package Dona.Lists;

public class TryCatch {
    public static void main(String[] args) {
        try {
            int[] a = {1, 2, 3};
            System.out.println(a[1]);
        } catch (Exception ex) {
            System.out.println("qayerdadir xato bor");
        } finally {
            System.out.println("try va catch ishi tugadi");
        }

    }
}
