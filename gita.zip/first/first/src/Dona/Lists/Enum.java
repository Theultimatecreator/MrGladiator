package Dona.Lists;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class Enum {
    enum myVar {
        Qish,
        Yoz,
        Kuz,
        Bahor
    }

    public static void main(String[] args) {
        myVar yoqtirganfasl = myVar.Yoz;
//        System.out.println(yoqtirganfasl);
        switch (yoqtirganfasl) {
            case Bahor -> System.out.println("I like bahor");
            case Yoz -> System.out.println("I like yoz");
            case Kuz -> System.out.println("I like kuz");
            case Qish -> System.out.println("I like qish");
        }
        for (myVar elemet : myVar.values()) {
            System.out.println(elemet);
        }
//        localDate
        LocalDate dates = LocalDate.now();
        System.out.println(dates);
        LocalTime times = LocalTime.now();
        System.out.println(times);
        LocalDateTime Dt = LocalDateTime.now();
        System.out.println("qoshilgan holatda chiqishi");
        System.out.println(Dt);
        System.out.println("formatlangan holatda chiqishi");
        DateTimeFormatter Fdt = DateTimeFormatter.ofPattern("dd-MM-yyy HH:mm:ss");
        String formatDate = Dt.format(Fdt);
        System.out.println(formatDate);
    }
}
