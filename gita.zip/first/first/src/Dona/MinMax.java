package Dona;

import java.util.Scanner;

public class MinMax {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("n = ");
        int n = in.nextInt();
//        System.out.println("min = ");
        int min = in.nextInt();
        int max = min;
        for (int i = 1; i < n; i++) {
            int a = in.nextInt();
            if (min > a) {
                min = a;
            }
            if (max < a) {
                max = a;
            }
        }
        System.out.println("min = " + min);
        System.out.println("max = " + max);
    }
}

class MinMax2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a = in.nextInt();
        int b = in.nextInt();
        int min = a * b;
        for (int i = 1; i < n; i++) {
            int d = in.nextInt();
            int k = in.nextInt();
            int s = d * k;
            if (min > s){
                min = s;
            }
        }
        System.out.println("minimal yuzacha = " + min);
    }
}