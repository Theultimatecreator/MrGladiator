package Dona;

import java.util.Scanner;

public class integer25 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int k = in.nextInt();
//        1-yanvar payshanba
//        0-yakshanba 1-dushanba 2-seshanba 3-chorshanba 4-payshanba 5-juma 6-shanba 7-yakshanba
        System.out.println((k+3)% 7 + " - kuniga");
    }
}
