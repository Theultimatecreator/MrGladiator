package Dona.Polimorf.Interface.Interface2;

public class Airplane implements Fly {
    @Override
    public void fly() {
        System.out.println("samalyot ucha oladi");
    }
}
