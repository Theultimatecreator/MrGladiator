package Dona.Polimorf.Interface.Interface2;

public class Main {
    public static void main(String[] args) {
        Fly uchish1 = new Airplane();
        uchish1.fly();
        Fly uchish2 = new Kabutar();
        uchish2.fly();

        Fly uchish3 = new Pinguin();
        uchish3.fly();

    }
}
