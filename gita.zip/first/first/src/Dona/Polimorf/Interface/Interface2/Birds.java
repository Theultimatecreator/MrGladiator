package Dona.Polimorf.Interface.Interface2;

public abstract class Birds implements Fly, Swim  {
    public void eat() {
        System.out.println("yeydi");
    }

    public void sleep() {
        System.out.println("uxlidi");
    }

    public void fly() {
        System.out.println("Birds can fly");
    }
}
