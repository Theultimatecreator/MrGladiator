package Dona.Polimorf.Interface.Interface2;

public class Kabutar extends Birds{
    @Override
    public void swims() {

    }
}
