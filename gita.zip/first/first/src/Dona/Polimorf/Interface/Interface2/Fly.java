package Dona.Polimorf.Interface.Interface2;

public interface Fly {
    public void fly();
}
