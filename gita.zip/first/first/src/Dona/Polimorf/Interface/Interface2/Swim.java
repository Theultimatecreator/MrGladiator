package Dona.Polimorf.Interface.Interface2;

public interface Swim {
    public void swims();
}
