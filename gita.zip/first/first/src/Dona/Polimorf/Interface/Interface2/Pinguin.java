package Dona.Polimorf.Interface.Interface2;
public class Pinguin extends Birds{
    @Override
    public void fly() {
        System.out.println("ucha olmaydi");
    }

    @Override
    public void swims() {

    }
}
