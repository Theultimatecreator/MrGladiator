package Dona.Polimorf.Interface;

public class Main {
    public static void main(String[] args) {
        Birds qushlar1 = new Kabutar();
        qushlar1.fly();
        qushlar1.eat();
        Birds qushlar2 = new Pingvin();
        qushlar2.fly();
        qushlar2.eat();
    }
}
