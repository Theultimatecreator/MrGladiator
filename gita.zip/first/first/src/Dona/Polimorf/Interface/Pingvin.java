package Dona.Polimorf.Interface;

public class Pingvin extends Birds {
    @Override
    public void fly() {
        System.out.println("pinguin ucha olmaydi");
    }
}
