package Dona.Polimorf.Interface;

public class Kabutar extends Birds {
    @Override
    public void fly() {
        System.out.println("Kabutar uchadi");
    }
}
