package Dona.Polimorf.Interface;

public abstract class Birds {
    public void eat(){
        System.out.println("yeydi");
    }
    public void sleep(){
        System.out.println("uxlidi");
    }
    public abstract void fly();
}
