package Dona.Polimorf.Abstract.Shape;

public class Triangle {
}
