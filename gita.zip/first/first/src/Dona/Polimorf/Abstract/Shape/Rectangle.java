package Dona.Polimorf.Abstract.Shape;

public class Rectangle extends Shape{
    double length;
    double width;
    public Rectangle(String color, double length, double width){
        super(color);
        System.out.println("Rectangle constructor");
        this.length = length;
        this.width = width;
    }

    @Override
    double area() {
        return length * width;

    }

    @Override
    public String toString() {
        return "rectangle rangi " + super.getColor() + " maydoni = " + area();
    }
}
