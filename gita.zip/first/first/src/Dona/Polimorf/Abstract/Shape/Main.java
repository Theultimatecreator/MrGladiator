package Dona.Polimorf.Abstract.Shape;

public class Main {
    public static void main(String[] args) {
        Shape shape1 = new Circle("red", 3.5);
        Shape shape2 = new Rectangle("blue", 5.2, 5);

        System.out.println(shape1);
        System.out.println(shape2);

    }
}
