package Dona.Polimorf.Abstract;

public abstract class Sayt {
    String name;

    public void userUrl() {
        System.out.println("Faqat oddiy userlar uchun!");
    }

    public void adminUrl() {
        System.out.println("Faqat Admin uchun!");
    }
    public abstract void getSayt();
}
