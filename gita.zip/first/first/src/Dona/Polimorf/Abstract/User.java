package Dona.Polimorf.Abstract;

public class User extends Sayt {
    @Override
    public void userUrl() {
        super.userUrl();
    }

    @Override
    public void adminUrl() {
        super.adminUrl();
    }

    public void getSayt() {
        System.out.println(name);
    }
}
