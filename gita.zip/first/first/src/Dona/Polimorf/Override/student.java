package Dona.Polimorf.Override;

public class student extends Person {


//    @Override
//    void show() {
//        super.show();
//        System.out.println("child show()");
//    }

    @Override
    protected void show2() {
        super.show2();
    }
    //    student() {
//        super();
//        System.out.println("student constructor");
//    }

//    1) String name = "Azamat";
//    void message() {
//        System.out.println("this is child class!");
//    }
//    void display(){
//        System.out.println("name = " + this.name);
//        System.out.println("name = " + super.name);
//        message();
//        super.message();
//    }
}
