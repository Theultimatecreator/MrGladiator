package Dona.Polimorf.Override;

public class Person {
    private void show(){
        System.out.println("person show()");
    }
    final void show3(){

    }
    protected void show2(){
        System.out.println("person show2()");
    }


//   1) Person(){
//        System.out.println("Person constructor");
//    }
//    String name = "Aziz Ota";
//    void message() {
//        System.out.println("this is parent class!");
//    }
}
