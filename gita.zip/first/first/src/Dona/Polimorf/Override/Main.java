package Dona.Polimorf.Override;

import java.lang.reflect.Parameter;

public class Main {
    public static void main(String[] args) {


        Person object1 = new Person();
        object1.show2();
//        st.display();

//    1)    Person object2 = new student();
//        object2.show();

    }
}
