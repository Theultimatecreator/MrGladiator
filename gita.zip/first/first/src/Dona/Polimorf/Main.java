package Dona.Polimorf;

public class Main {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        System.out.println(" add(int a, int b): " + calculator.add(2, 6));
        System.out.println(" add(int a, int b, int c): " + calculator.add(2, 16, 56));
        System.out.println(" add(int a, int b, double c): " + calculator.add(2, 16, 56.6));
        String s = calculator.add(6, 5, 2.3);
        System.out.println(s);
    }
}
