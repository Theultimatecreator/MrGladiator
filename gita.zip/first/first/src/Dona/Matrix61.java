package Dona;

import java.util.Scanner;

public class Matrix61 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int m = in.nextInt();
        int n = in.nextInt();
        int t = 1;
        int a[][] = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = t++;
                System.out.print(a[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println("qaysi satrni o'chirasiz!!");
        int k = in.nextInt();
        for (int i = k; i < m - 1; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = a[i + 1][j];
            }
            System.out.println();
        }
        System.out.println("natija ");
        for (int i = 0; i < m - 1; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(a[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
