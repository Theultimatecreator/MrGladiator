package Dona;

import java.util.Scanner;

public class minmax27 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int num = in.nextInt();
        int k = 1, count = 0, index = 1, ind = 1;
        for (int i = 2; i <= n; i++) {
            int num2 = in.nextInt();
            if (num == num2) {
                k++;
                if (count < k) {
                    count = k;
                    index = ind;
                }
            } else {
                num = num2;
                ind = i;
                k = 1;
            }
        }
        System.out.println(index + " " + count);
    }
}
