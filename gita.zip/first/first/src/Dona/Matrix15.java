package Dona;

import java.util.Scanner;

public class Matrix15 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int m = in.nextInt();
        int a[][] = new int[m][m];
        int qiymat = 1;
        int satrBoshi = 0;
        int satrOxiri = m - 1;
        int ustunBoshi = 0;
        int ustunOxiri = m - 1;
        while (satrBoshi <= satrOxiri && ustunBoshi <= ustunOxiri && qiymat <= m * m) {
            for (int i = ustunBoshi; i <= ustunOxiri; i++) {
                a[satrBoshi][i] = qiymat++;
            }
            satrBoshi++;
            for (int i = satrBoshi; i <= satrOxiri; i++) {
                a[i][ustunOxiri] = qiymat++;
            }
            ustunOxiri--;
            for (int i = ustunOxiri; i >= ustunBoshi; i--) {
                a[satrOxiri][i] = qiymat++;
            }
            satrOxiri--;
            for (int i = satrOxiri; i >= satrBoshi; i--) {
                a[i][ustunBoshi] = qiymat++;
            }
            ustunBoshi++;

        }

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(a[i][j] + "\t");
            }
            System.out.println(" ");
            System.out.println(" ");
        }
    }
}
