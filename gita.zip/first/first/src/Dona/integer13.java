package Dona;

import java.util.Scanner;

public class integer13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();

        System.out.println(n%100*10+n/100);
    }
}
