package Abdulaziz;

import java.util.Scanner;

public class forExample {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        for (int i = 1; i <= 100; i++) {
            if (i % 2 == 0)
                System.out.print(i + " ");
        }
        System.out.println();
        for (int i = 100; i >= 1; i--) {
            if (i % 2 != 0)
                System.out.print(i + " ");
        }
    }
}
class ass{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        if (n % 4==0 && n %100!=0 || n % 400 == 0)
            System.out.println("Kabisa yili");
        else
            System.out.println("Kabisa yili emas");
    }
}
