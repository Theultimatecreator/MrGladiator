package Abdulaziz;

import java.util.Scanner;

public class while1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        int b = in.nextInt();
        int x = a - b;
        int l = 1;
        while (x >= b) {
            x -= b;
            l++;
        }
        System.out.println(l);
    }
}

class while2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int k = in.nextInt();
        int butun = 0;
        while (n >= k) {
            n -= k;
            butun++;
        }
        System.out.println("butun = " + butun);
        System.out.println("qoldiq = " + n);
    }
}

class while4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int daraja = 1;
        while (daraja <n) {
            daraja *= 3;

        }
        if (daraja == n) {
            System.out.println("3 ning darajasi");
        } else {
            System.out.println("3 ning darajasi emas");
        }
    }
}