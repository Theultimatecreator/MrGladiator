package Abdulaziz;

public class example2 {
    public static void main(String[] args) {
        int s=0;
        double p = 1;
        for (int i = 0; i <= 100; i+=2) {
            s+=i;
        }
        System.out.println("summasi = " + s);
        System.out.println();
        for (int i = 1; i < 100; i+=2) {
            p*=i;
        }
        System.out.println("ko'paytmasi = " + p);
    }
}
