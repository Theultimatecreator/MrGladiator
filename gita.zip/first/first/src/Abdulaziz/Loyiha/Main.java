package Abdulaziz.Loyiha;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
            Scanner in = new Scanner(System.in);
            Book book = new Book();
            Library lib = new Library();
            rep:
            while (true){
                System.out.println("1 - add");
                System.out.println("2 - read");
                System.out.println("3 - search");
                System.out.println("4 - Info");
                System.out.println("0 - exit");
                switch (in.nextInt()){
                    case 1 -> lib.add();
                    case 2 -> lib.read();
                    case 3 -> lib.search();
//                    case 4 -> book.bookInfo();
                    case 0 -> {
                        System.out.println("Dastur yopildi");
                        break rep;
                    }
                }
            }

    }
}
