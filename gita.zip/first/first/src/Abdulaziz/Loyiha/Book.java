package Abdulaziz.Loyiha;

import java.util.ArrayList;

public class Book {
    ArrayList<Book> kitoblar = new ArrayList<>();
    private String muallif;
    private String nomi;
    private String turi;
    private String nashriyoti;
    private int year;

    public String getMuallif() {
        return muallif;
    }

    public void setMuallif(String muallif) {
        this.muallif = muallif;
    }

    public String getNomi() {
        return nomi;
    }

    public void setNomi(String nomi) {
        this.nomi = nomi;
    }

    public String getTuri() {
        return turi;
    }

    public void setTuri(String turi) {
        this.turi = turi;
    }

    public String getNashriyoti() {
        return nashriyoti;
    }

    public void setNashriyoti(String nashriyoti) {
        this.nashriyoti = nashriyoti;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
//    public void bookInfo(){
//        for (int i = 0; i < kitoblar.size(); i++) {
//            Book x = kitoblar.get(i);
//            if (x.getNomi().contains(nomi))
//                System.out.println("|   №   |\t\tNomi\t\t|\t\tMuallif\t\t|\t\tNashriyot\t\t|\t\tTuri\t\t|\t\tYili\t\t|");
//            System.out.println(" \t"+i + "\t\t\t\t" + x.getNomi()+ "\t\t\t\t" + x.getMuallif() + "\t\t\t\t" + x.getNashriyoti() + "\t\t\t\t" + x.getTuri() + "\t\t\t\t" + x.getYear());
//        }
//    }
}
