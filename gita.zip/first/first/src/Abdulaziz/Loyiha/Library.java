package Abdulaziz.Loyiha;

import java.util.ArrayList;
import java.util.Scanner;

public class Library {
    Scanner in = new Scanner(System.in);
    ArrayList<Book> kitoblar = new ArrayList<>();
    void add(){
        Book yangi_kitoblar = new Book();
        System.out.print("Nomi: ");
        yangi_kitoblar.setNomi(in.next());
        System.out.print("Muallifi: ");
        yangi_kitoblar.setMuallif(in.next());
        System.out.print("Nashriyoti: ");
        yangi_kitoblar.setNashriyoti(in.next());
        System.out.print("Turi: ");
        yangi_kitoblar.setTuri(in.next());
        System.out.print("Yili: ");
        yangi_kitoblar.setYear(in.nextInt());
        kitoblar.add(yangi_kitoblar);
    }
    void read(){
        for (int i = 1; i < kitoblar.size(); i++) {
            Book y = kitoblar.get(i);
            System.out.println("|   №   |\t\tNomi\t\t|\t\tMuallif\t\t|\t\tNashriyot\t\t|\t\tTuri\t\t|\t\tYili\t\t|");
            System.out.println(" \t"+i + "\t\t\t\t" + y.getNomi()+ "\t\t\t\t" + y.getMuallif() + "\t\t\t\t" + y.getNashriyoti() + "\t\t\t\t" + y.getTuri() + "\t\t\t\t" + y.getYear());
        }
    }
    void search(){
        System.out.println("Izlangan kitobni Nomi:");
        String nomi = in.next();
        for (int i = 0; i < kitoblar.size(); i++) {
            Book x = kitoblar.get(i);
            if (x.getNomi().contains(nomi))
                System.out.println("|   №   |\t\tNomi\t\t|\t\tMuallif\t\t|\t\tNashriyot\t\t|\t\tTuri\t\t|\t\tYili\t\t|");
            System.out.println(" \t"+i + "\t\t\t\t" + x.getNomi()+ "\t\t\t\t" + x.getMuallif() + "\t\t\t\t" + x.getNashriyoti() + "\t\t\t\t" + x.getTuri() + "\t\t\t\t" + x.getYear());
        }
    }

}
