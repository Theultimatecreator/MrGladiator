package Abdulaziz;

import java.util.Scanner;

public class MethodsLesson {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        int b = in.nextInt();
        System.out.println(kattaKichik(a, b));
        KattaKichik(a, b);
    }
    public static int kattaKichik(int a, int b){
        if (a > b)
            return a;
        return b;
    }
    public static void KattaKichik(int a, int b){
        if (a > b)
            System.out.print(a + " > " + b);
        else
            System.out.print(a + " < " + b);
    }

}
