package Abdulaziz.Massiv;

import java.util.Scanner;

public class matrxi {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("satr : ");
        int m = in.nextInt();
        System.out.print("ustun : ");
        int n = in.nextInt();
        int a[][] = new int[m][n];
        int t = 1;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = t++;
            }
        }
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = 10 * i;
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }
    }
}
