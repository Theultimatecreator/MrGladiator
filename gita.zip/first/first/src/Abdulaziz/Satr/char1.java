package Abdulaziz.Satr;

import java.time.LocalDate;
import java.util.Scanner;

public class char1 {
    public static void main(String[] args) {
//        char letter = 'A';
//        String letter2 = "Asad";
//        System.out.println((int)letter);
//        System.out.println(letter2);
//
//        char s1 = '@';
//        System.out.println((int)s1);
//        char a = 43;
//        System.out.println(a);

        Scanner in = new Scanner(System.in);
//        char letter = in.next().charAt(0);
//        System.out.println((int)letter);

        int n = in.nextInt();
        char letter = 'a';
        for (int i = 0; i < n; i++) {
            System.out.print(letter++ + " ");
        }
    }
}

class Date{
    public static void main(String[] args) {
        Scanner intScanner = new Scanner(System.in);
        int year = intScanner.nextInt();
        LocalDate localDate = LocalDate.of(year,1,1);
        int i=0;
        int count = 0;
        while (true) {
            if(localDate.plusDays(i).getDayOfWeek().toString().equals("FRIDAY")){
                count++;
            }
            if(count==10){
                System.out.println(localDate.plusDays(i));
                break;
            }
            i++;
        }
    }
}