package p_02_integer;

import java.util.Scanner;

public class integer13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("uch xonali son = ");
        int a = in.nextInt(), natija;
//        321  21 + 3
        natija = a % 100 * 10 + a / 100;
        System.out.println("natija = " + natija);
    }
}
