package p_02_integer;

import java.util.Scanner;

public class integer24 {
    public static void main(String[] args) {
        Scanner kirit = new Scanner(System.in);
        int k;
        System.out.print("k = ");
        k = kirit.nextInt();//k 1 va 365 orasidagi kun
        //0-yakshanba  1-dushanba 2-sesh, 3-chor, 4-pay, 5-ju, 6-shan
        System.out.println(k % 7 + "- kuni");
    }
}
