package p_02_integer;


import java.util.Scanner;

public class integer28 {
    public static void main(String[] args) {
        Scanner integer28 = new Scanner(System.in);
        System.out.print("kun raqami k = ");
        int k = integer28.nextInt();
        System.out.print("Hafta kunlari n = ");
        int n = integer28.nextInt();
        System.out.print(((k + n - 2) % 7) + 1 +" kuniga teng ");

    }
}
