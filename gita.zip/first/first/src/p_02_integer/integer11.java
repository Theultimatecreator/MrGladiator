package p_02_integer;

import java.util.Scanner;

public class integer11 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("uch xonali son = ");
        int a = in.nextInt();
        System.out.println("Yuzlar xonasi = " + a / 100);
        System.out.println("O'nliklar xonasidagi raqam = " + (a / 10) % 10);
        System.out.println("Birliklar xonasidagi raqam = " + (a % 10));
        System.out.println("yig'indi = " + (a / 100 + ((a / 10) % 10) + a % 10));
    }
}
