package p_02_integer;

import java.util.Scanner;

public class integer23 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("N = ");
        int N = in.nextInt();
        double minut = N / 60, natija = N / 60 / 60;
        System.out.println("kun boshidan " + natija + " soat o'tdi ");
        System.out.println("kun boshidan " + minut + " minut o'tdi ");
        System.out.println("kun boshidan " + N + " sekund o'tdi ");

    }
}
