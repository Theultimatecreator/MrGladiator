package p_02_integer;

import java.util.Scanner;

public class integer1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double L;
        System.out.print("l = ");
        L = in.nextDouble();
        double natija = L / 100;
        System.out.print("natija = " +natija +" m ");
    }
}
