package p_02_integer;

import java.util.Scanner;

public class integer9 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("uch xonali son = ");
        int a = in.nextInt();
        System.out.println("Yuzlar xonasi = " + a / 100);

    }
}
