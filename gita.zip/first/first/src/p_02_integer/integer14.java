package p_02_integer;

import java.util.Scanner;

public class integer14 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("uch xonali son = ");
        int a = in.nextInt(), natija;
//        321  1* 100 + 32
        natija = a % 10 * 100 + a / 10;
        System.out.println("natija = " + natija);
    }
}
