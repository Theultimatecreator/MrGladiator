package p_02_integer;

import java.util.Scanner;

public class integer25 {
    public static void main(String[] args) {
        Scanner integer25 = new Scanner(System.in);
        int k;
        System.out.print("k = ");
        k = integer25.nextInt();
        System.out.println((k - 3) % 7 + "-kuni");
    }
}
