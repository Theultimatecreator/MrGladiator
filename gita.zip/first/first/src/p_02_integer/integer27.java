package p_02_integer;

import java.util.Scanner;

public class integer27 {
    public static void main(String[] args) {
        Scanner integer27 = new Scanner(System.in);
        int k;
        System.out.print("k = ");
        k = integer27.nextInt();
        System.out.println((((k - 1) % 7) - 1) + "-kun");
    }

}
