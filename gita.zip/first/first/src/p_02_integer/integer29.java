package p_02_integer;

import java.util.Scanner;

public class integer29 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("A = ");
        int A = in.nextInt();
        System.out.print("B = ");
        int B = in.nextInt();
        System.out.print("C = ");
        int C = in.nextInt();
        System.out.print("To`rtburchakka " + (A/C*B/C) + "marta kvadrat joylash mumkin");
    }
}
