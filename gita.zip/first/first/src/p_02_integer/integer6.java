package p_02_integer;

import java.util.Scanner;

public class integer6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("ikki xonali son = ");
        int a = in.nextInt();
        System.out.println("O'nliklar xonasidagi raqam = " + (a  / 10));
        System.out.println("Birliklar xonasidagi raqam = " + (a  % 10));

    }
}
