package p_02_integer;

import java.util.Scanner;

public class integer3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double bayt;
        System.out.print("bayt = ");
        bayt = in.nextDouble();
        double k_bayt = bayt / 1024;
        System.out.print("natija = " + k_bayt + "kbayt");
    }
}
