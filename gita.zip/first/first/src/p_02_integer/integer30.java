package p_02_integer;

import java.util.Scanner;

public class integer30 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Yil = ");
        int yil = in.nextInt();
        System.out.print(yil * 100 - 100 + " yilning boshi");

    }
}
