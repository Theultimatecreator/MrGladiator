package p_02_integer;

import java.util.Scanner;

public class integer4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int A, B;
        System.out.print("A = ");
        A = in.nextInt();
        System.out.print("B = ");
        B = in.nextInt();
        int natija = A / B;
        System.out.print("natija = " +natija +" ta joylash mumkin ");
    }
}
