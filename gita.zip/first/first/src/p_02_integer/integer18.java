package p_02_integer;

import java.util.Scanner;

public class integer18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("son kiriting = ");
        int a = in.nextInt();
        int natija = (a / 100) / 10;
        System.out.println("natija = " + natija);
    }
}
