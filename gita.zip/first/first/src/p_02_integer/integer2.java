package p_02_integer;

import java.util.Scanner;

public class integer2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double M;
        System.out.print("M = ");
        M = in.nextDouble();
        double natija = M / 1000;
        System.out.print("natija = " +natija +" kg ");
    }
}
