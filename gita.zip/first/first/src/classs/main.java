package classs;

public class main {
    public static void main(String[] args) {
        Car car1 = new Car(); //car1 obyekt nomi
        car1.km = 300;
        car1.color = "Black";
        car1.model = "Tracker";
        car1.maxSpeed = 220;
        car1.year = 2021;
        car1.number = "01 A 777AA";

        Car car2 = new Car();
        car2.year = 2020;
        car2.number = "01 A 333BB";
        car2.maxSpeed = 210;
        car2.model = "Malibu";
        car2.color = "White";
        car2.km = 400;
        car2.state = true;
        System.out.println("**************car1***********");
        System.out.println("model = " + car1.model);
        System.out.println("number = " + car1.number);
        System.out.println("year = " + car1.year);
        System.out.println("color = " + car1.color);
        System.out.println("state = " + car1.state);

        System.out.println("**************car2***********");
        System.out.println("model = " + car2.model);
        System.out.println("number = " + car2.number);
        System.out.println("year = " + car2.year);
        System.out.println("color = " + car2.color);
        System.out.println("state = " + car2.state);

        System.out.println("\n**********Objectlarning metodlarini ishlatish**********");
        System.out.println("**************car1***********");
        car1.startOn();
        System.out.println("model = " + car1.model);
        System.out.println("number = " + car1.number);
        System.out.println("year = " + car1.year);
        System.out.println("color = " + car1.color);
        System.out.println("state = " + car1.state);

        System.out.println("**************car2***********");
        car2.startOff();
        System.out.println("model = " + car2.model);
        System.out.println("number = " + car2.number);
        System.out.println("year = " + car2.year);
        System.out.println("color = " + car2.color);
        System.out.println("state = " + car2.state);
    }
}
