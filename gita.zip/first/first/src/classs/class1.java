package classs;

import javax.swing.plaf.metal.MetalTabbedPaneUI;
import java.util.Scanner;

public class class1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = 7;
        int b = 3;
        System.out.println(Integer.toBinaryString(a^b));
        System.out.println("Salom \r\\");
        System.out.println(12.4%3.2);


    }
}
