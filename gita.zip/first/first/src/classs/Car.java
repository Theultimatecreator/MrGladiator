package classs;

public class Car {
    String model;
    String color; //rangi
    String number; //davlat raqami
    int year; //ishlab chiqarilgan yili
    int maxSpeed; // eng yuqori tezligi
    double km; //moshinani umumiy bosib o'tgan yo'li
    boolean state;//o'chiq yoki yongan
    //barcha atributlarni yozib chiqdik

    void startOn() {
        state = true;
        System.out.println("mashina o't oldi");
    }

    void startOff() {
        state = false;
        System.out.println("mashina o'chdi");
    }

    void drive(double distance) {
        km += distance;
        System.out.println("mashina " + distance + " masofani bosib o'tdi");
    }


}
