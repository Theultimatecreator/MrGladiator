import java.util.Scanner;

public class buluvchi {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();
        for (int i = 1; i <= n; i ++){
            if(n % i == 0)
                System.out.print(i + " ");
        }
    }
}
