package Array;

import java.util.Scanner;

public class array17 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();
        int k = 0;
        int t = n - 1;
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }

        for (int i = 0; i < n; i++) {
            if (i % 4 < 2) {
                System.out.print(a[k++] + " ");
            } else {
                System.out.print(a[t--] + " ");
            }
        }

    }
}
