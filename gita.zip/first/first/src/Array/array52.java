package Array;

import java.util.Scanner;

public class array52 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        double b[] = new double[a.length];
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
            if (a[i] < 5){
                b[i] = a[i] * 2;
            }
            else
                b[i] = 1f * a[i] / 2;
            System.out.println(b[i] +" ");
        }

    }
}
