package Array;

import java.util.Scanner;

public class array11 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();
        int k = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        for (int j = 0; j < a.length; j += k) {
            System.out.print("a[" + j + "] = " + a[j] + " ");
        }
    }
}
