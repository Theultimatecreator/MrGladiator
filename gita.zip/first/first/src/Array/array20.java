package Array;

import java.util.Scanner;

public class array20 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int k = in.nextInt();
        int l = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        int sum = 0;
        for (int i = k+1; i < l; i++) {
            System.out.print("a[" + i + "] = " + a[i] + " ");
            sum += a[i];
        }
        System.out.println("yigindisi = " + sum);

    }
}
