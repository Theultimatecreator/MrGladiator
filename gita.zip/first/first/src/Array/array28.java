package Array;

import java.util.Scanner;

public class array28 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        a[0] = in.nextInt();
        int b = a[0];
        int index = 0;
        for (int i = 1; i < a.length; i++) {
            a[i] = in.nextInt();
            if (i % 2 == 0) {
                if (b > a[i]) {
                    b = a[i];
                    index = i;
                }
            }
        }
        System.out.println(b + " " + index);

    }
}
