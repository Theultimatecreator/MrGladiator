package Array;

import java.util.Scanner;

public class array33 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        int d = 0;
        for (int i = 1; i < n - 1; i++) {
            if (a[i] > a[i - 1] && a[i] < a[i + 1]) {
                d = 1;
            }
        }
        System.out.println(d + " ");
    }
}
