package Array;

import java.util.Scanner;

public class array25 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        double q = a[1] * 1d / a[0];
        boolean t = true;
        for (int i = 2; i < a.length; i++) {
            if (q != a[i] * 1d / a[i - 1]) {
                t = false;
                break;
            }
        }
        if (t)
            System.out.println(q);
        else
            System.out.println(0);
    }
}
