package Array;

import java.util.Scanner;

public class array34 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        int min = Integer.MIN_VALUE;
        for (int i = 1; i < a.length - 1; i++) {
            if (a[i] < a[i - 1] && a[i] < a[i + 1]) {
                if (min < a[i]) {
                    min = a[i];
                }
            }
        }
        System.out.println(min + " ");
    }
}
