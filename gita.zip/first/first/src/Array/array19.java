package Array;

import java.util.Scanner;

public class array19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        int index = 0;
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        for (int i = 0; i < a.length; i++) {
            if (a[0] < a[i] && a[i] < a[n - 1]) {
                index = a[i];
            }
        }
        System.out.println(index);
    }
}
