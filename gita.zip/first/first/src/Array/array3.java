package Array;

import java.util.Scanner;

public class array3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();
        System.out.print("A = ");
        int A = in.nextInt();
        System.out.print("D = ");
        int D = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = A + i * D;//Arifmetik progressiya formulasi
        }
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
    }
}
