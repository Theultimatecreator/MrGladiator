package Array;

import java.util.Scanner;

public class array29 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        a[0] = in.nextInt();
        a[1] = in.nextInt();
        int b = a[1];
        for (int i = 2; i < a.length; i++) {
            a[i] = in.nextInt();
            if (i % 2 == 1) {
                if (b < a[i]) {
                    b = a[i];
                }
            }
        }
        System.out.println(b + " ");
    }
}
