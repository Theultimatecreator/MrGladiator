package Array;

import java.util.Scanner;

public class array4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();
        System.out.print("A = ");//Dastlabgi had
        int A = in.nextInt();
        System.out.print("D = ");
        int D = in.nextInt(); // maxraj
        int p = 1;
        int a[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] =A * p;//Geometrik progressiya formulasi
            p *= D;
        }
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
    }
}
