package Array;

import java.util.Scanner;

public class array23 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int k = in.nextInt();
        int l = in.nextInt();
        int a[] = new int[n];
        int sum = 0, soni = 0;
        double arf = 0;
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
            if (i > k && i < l) {
                continue;
            }
            soni++;
            sum += a[i];
        }
        arf = (sum * 1d) / soni;
        System.out.println(arf);
    }
}
