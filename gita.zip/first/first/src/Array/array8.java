package Array;

import java.util.Scanner;

public class array8 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();
        int a[] = new int[n];
        int k = 0;
        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();
        }
        for (int i = 0; i <a.length; i++) {
            if (a[i] % 2 != 0){
                k++;
                System.out.print("a[" + i + "] = " + a[i] + " ");
            }

        }
        System.out.print("toqlar soni = " + k);
    }
}
