package Array;

import java.util.Scanner;

public class array53 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        int b[] = new int[n];
        int c[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        for (int i = 0; i < b.length; i++) {
            b[i] = in.nextInt();
            c[i] = Math.max(a[i], b[i]);
            System.out.print(c[i] + " ");
        }
    }
}
