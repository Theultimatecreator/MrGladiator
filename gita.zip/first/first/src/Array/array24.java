package Array;

import java.util.Scanner;

public class array24 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        int d = a[1] - a[0];
        boolean t = true;
        for (int i = 2; i < a.length; i++) {
            if (d != a[i] - a[i - 1]) {
                t = false;
                break;
            }
        }
        if (t)
            System.out.println(d);
        else
            System.out.println(0);
    }
}
