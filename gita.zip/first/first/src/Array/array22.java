package Array;

import java.util.Scanner;

public class array22 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int k = in.nextInt();
        int l = in.nextInt();
        int a[] = new int[n];
        int sum = 0;
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
            if (i > k && i < l) {
                continue;
            }
            sum += a[i];
        }
        System.out.println(sum + " ");
    }
}
