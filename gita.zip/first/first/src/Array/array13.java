package Array;

import java.util.Scanner;

public class array13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        for (int i = a.length - 1; i >= 1; i-=2) {
            System.out.print("a[" + i + "] = " + a[i] + " ");
        }
    }
}
