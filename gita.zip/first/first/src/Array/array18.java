package Array;

import java.util.Scanner;

public class array18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int array[] = new int[n];
        int index = 0;
        for (int i = 0; i < array.length; i++) {
            array[i] = in.nextInt();
        }
        for (int i = 0; i < array.length; i++) {
            if (array[i] < array[n - 1]) {
                index = array[i];
                break;
            }
        }
        System.out.println(index);
    }
}
