package Array;

import java.util.Scanner;

public class array2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        int p = 1;
        int k = 2;
        for (int i = 0; i < a.length; i++) {
            a[i] = p;
            p *= k;
        }
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
    }
}
