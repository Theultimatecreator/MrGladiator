package Array;

import java.util.Scanner;

public class array5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();

        int F[] = new int[n];
        F[0] = 1;
        F[1] = 1;
        for (int i = 2; i < F.length; i++) {
            F[i] = F[i - 1] + F[i - 2];
        }
        for (int i = 0; i < F.length; i++) {
            System.out.print(F[i] + " ");
        }
    }
}
