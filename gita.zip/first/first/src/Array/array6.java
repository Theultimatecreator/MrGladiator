package Array;

import java.util.Scanner;

public class array6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();
        System.out.print("A = ");
        int A = in.nextInt();
        System.out.print("B = ");
        int B = in.nextInt();
        int a[] = new int[n];
        a[0] = A;
        a[1] = B;
        a[2] = A + B;
        for (int i = 3; i < a.length; i++) {
            a[i] = a[i - 1] * 2;
        }
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
    }
}
