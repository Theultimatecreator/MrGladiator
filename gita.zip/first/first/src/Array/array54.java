package Array;

import java.util.Scanner;

public class array54 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        int b[] = new int[n];
        int k = 0;
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
            if (a[i] % 2 == 0) {
                b[k++] = a[i];

            }
        }
        System.out.println(k + " ");
        for (int i = 0; i < k; i++) {
            System.out.print(b[i] + " ");
        }
    }
}
