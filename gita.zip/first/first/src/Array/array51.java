package Array;

import java.util.Scanner;

public class array51 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a[] = new int[n];
        int b[] = new int[n];
        System.out.println("a massivni kiriting:");
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        System.out.println("b massivni kiriting:");
        for (int i = 0; i < a.length; i++) {
            b[i] = in.nextInt();
            int m = a[i];
            a[i] = b[i];
            b[i] = m;

        }
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");

        }
        System.out.println();
        for (int i = 0; i < b.length; i++) {
            System.out.print(b[i] + " ");
        }
    }
}
