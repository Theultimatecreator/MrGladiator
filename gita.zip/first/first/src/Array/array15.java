package Array;

import java.util.Scanner;

public class array15 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = in.nextInt();
        }
        for (int i = 1; i < a.length; i+=2) {
            System.out.print("a[" + i + "] = " + a[i] + " ");
        }
        for (int i = a.length - 2; i >= 0; i-=2) {
            System.out.print("a[" + i + "] = " + a[i] + " ");
        }
    }
}
