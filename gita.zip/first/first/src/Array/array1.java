package Array;

import java.util.Scanner;

public class array1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();
        int a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = 2 * i + 1;
        }
        for (int i = 0; i < n; i++) {
            System.out.print("a[" + i + "] = " + a[i] + " ");
        }
    }
}
