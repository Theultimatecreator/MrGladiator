import java.util.Scanner;

public class DostSon {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        for (int i = 1; i <= n; i++) {
            int num = sum(i);
            if (num > i && i == sum(num)){
                System.out.println(i + " " + num);
            }
        }

    }

    public static int sum(int n) {
        int sum = 1;
        return sum;
    }

}
