package max_min;

import java.util.Scanner;

public class maxmin3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("n sonini kiriting");
        int n = in.nextInt();
        System.out.println("birinchi a va b ni kiriting");
        int a = in.nextInt();
        int b = in.nextInt();
        int max = 2 * (a + b);
        for (int i = 2; i <= n; i ++){
            System.out.println(i +"- a va b ni kiriting ");
            a = in.nextInt();
            b = in.nextInt();
            if (max < 2 * (a + b)) max = 2 * (a + b);
        }
        System.out.printf("max %d", max);

    }
}
