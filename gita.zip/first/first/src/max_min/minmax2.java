package max_min;

import java.util.Scanner;

public class minmax2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("n kiritilsin =");
        int n = in.nextInt();
        System.out.println("1 - a va b ni kiriting: = ");
        int a = in.nextInt();
        int b = in.nextInt();
        int min = a * b;
        for (int i = 2; i <= n; i++) {
            System.out.println(i + "- a va b ni kiriting");
            a = in.nextInt();
            b = in.nextInt();

            if (min > a * b) min = a * b;
              }
        System.out.printf("Min %d", min);
    }
}
