package max_min;

import java.util.Scanner;

public class maxmin9 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();
        int max = in.nextInt();
        int d = 1;
        for (int i = 2; i <= n; i++) {
            int a = in.nextInt();
            if (a >= max) {
                max = a;
                d = i;
            }

        }
        System.out.println("max " + max +  " orni " + d);
    }
}
