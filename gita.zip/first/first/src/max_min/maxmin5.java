package max_min;

import java.util.Scanner;

public class maxmin5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n sonni kiriting =");
        int n = in.nextInt();
        System.out.print("m va v ni kiriting = ");
        double m = in.nextDouble(), v = in.nextDouble();
        double max = m / v;
        for (int i = 2; i <= n; i++) {
            System.out.print(i + "- m va v ni kiriting : ");
            m = in.nextDouble();
            v = in.nextDouble();
            if (max < m / v){max = m / v;}

        }
        System.out.print("Eng katta zichlik = " +max);

    }
}
