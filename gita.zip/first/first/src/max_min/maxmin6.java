package max_min;

import java.util.Scanner;

public class maxmin6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt();

        int max = in.nextInt();
        int min = max;
        int d = 1;
        for (int i = 2; i <= n; i++) {
            int a = in.nextInt();
            if (a < min) {
                min = a;

            }
            if (max <= a) {
                max = a;
                d = i;
            }
        }
        System.out.println("max " + max + " orni " + d + "\nmin " + min);
    }
}
