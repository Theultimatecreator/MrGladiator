package max_min;

import java.util.Scanner;

public class maxmin4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int n = in.nextInt(), k = 1;
        System.out.print("1 - sonni kiriting: ");
        int temp = in.nextInt();
        int min = temp;
//        int max = temp;
        for (int i = 2; i <= n; i++) {
            System.out.print(i + "- sonni kiriting : ");
            temp = in.nextInt();
            if (min > temp) {
                min = temp;
                k = i;
            }

        }
        System.out.printf("min %d, k = %d", min, k);
    }
}

class minmax6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int min = in.nextInt();
        int max = min;
        int minIndex = 1;
        int maxIndex = 1;
        //5->1 2 1 5 5
        for (int i = 2; i <= n; i++) {
            int a = in.nextInt();
            if (min >= a) {
                min = a;
                minIndex = i;
            }
            if (max <= a) {
                max = a;
                maxIndex = i;
            }
        }
        System.out.println("oxirgi max = " + max + " o'rni = " + maxIndex);
        System.out.println("birinchi min = " + min + " o'rni = " + minIndex);
    }
}


class minmax10 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int min = in.nextInt();
        int max = min;
        int minIndex = 1;
        int maxIndex = 1;
        for (int i = 2; i <= n; i++) {
            int a = in.nextInt();
            if (min > a) {
                min = a;
                minIndex = i;
            }
            if (max < a) {
                max = a;
                maxIndex = i;
            }
        }
        if (minIndex < maxIndex) {
            System.out.println("min extremal element = " + minIndex);
        } else {
            System.out.println("max extremal element = " + maxIndex);
        }
    }
}