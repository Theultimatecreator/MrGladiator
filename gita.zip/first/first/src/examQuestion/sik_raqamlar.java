package examQuestion;

import java.util.Scanner;

public class sik_raqamlar {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int i, j, k = 1;
        int n = in.nextInt();
        for (i = 1; i <= n ; i++) {
            for (j = 1; j <= i; j++)
                System.out.print(k++);
                System.out.println(" ");

        }
    }
}
