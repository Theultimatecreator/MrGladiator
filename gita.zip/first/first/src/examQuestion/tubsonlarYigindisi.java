package examQuestion;

import java.util.Scanner;

public class tubsonlarYigindisi {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int s = 0;
        for (int i = 2; i <= n; i++) {
            boolean tub = true;
            for (int j = 2; j <= i / 2; j++) {
                if (i % j == 0) {
                    tub = false;
                    break;
                }
            }
            if (tub) s += i;
        }
        System.out.println(s);
    }
}
