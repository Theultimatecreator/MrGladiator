package examQuestion;

public class exam2 {
}
