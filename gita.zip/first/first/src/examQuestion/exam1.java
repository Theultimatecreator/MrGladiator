package examQuestion;

import java.util.Scanner;

public class exam1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        System.out.print("b = ");
        int b = in.nextInt();
        System.out.print("c = ");
        int c = in.nextInt();
        if (a >= b && b <= c) {
            System.out.print(b);
        } else if (a >= b && b >= c) {
            System.out.print(c);
        } else if (b >= a && a <= c) {
            System.out.print(a);
        }

    }

}
