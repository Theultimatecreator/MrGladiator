package examQuestion;

import java.util.Scanner;

public class exam16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int min = in.nextInt();
        int max = min;
        int MinIndex = 1;
        int MaxIndex = 1;

        for (int i = 2; i <= n; i++) {
            int a = in.nextInt();
            if (min >= a) {
                min = a;
                MinIndex = i;
            }
            if (max <= a) {
                max = a;
                MaxIndex = i;
            }
        }
        if (MinIndex > MaxIndex) {
            System.out.println(min + " " + MinIndex);
        } else
            System.out.println(max + " " + MaxIndex);
    }
}
