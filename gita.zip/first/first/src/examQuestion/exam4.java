package examQuestion;

import java.util.Scanner;

public class exam4 {
    public static void main(String[] args) {
        Scanner task = new Scanner(System.in);
        System.out.println("Ikkita butun son berilgan Day (kun) va Month (oy).\n" +
                "(Kabisa bo'lmagan yil sanasi kiritiladi). \nBerilgan sanadan keyingi sanani " +
                "ifodalovchi programma tuzilsin.\n");

        System.out.print("Day: ");
        int day = task.nextInt();
        System.out.print("Month: ");
        int month = task.nextInt();

        switch (month) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10: {
                if ((day > 0) && (day < 31)) {
                    day = day + 1;
                } else if (day == 31) {
                    day = 1;
                    month = month + 1;
                } else {
                    System.out.println("Bunday sana yo'q");
                }
                break;
            }
            case 12: {
                if ((day > 0) && ((day < 31))) {
                    day = day + 1;
                } else if (day == 31) {
                    day = 1;
                    month = 1;
                } else {
                    System.out.println("Bunday sana yo'q");
                }
                break;
            }
            case 2: {
                if ((day > 0) && (day < 28)) {
                    day = day + 1;
                } else if (day == 28) {
                    day = 1;
                    month = month + 1;
                } else {
                    System.out.println("Bunday sana yo'q");
                }
                break;
            }
            case 4:
            case 6:
            case 9:
            case 11: {
                if ((day > 0) && (day < 30)) {
                    day = day + 1;
                } else if (day == 30) {
                    day = 1;
                    month = month + 1;
                } else {
                    System.out.println("Bunday sana yo'q");
                }
                break;
            }
            default:
                System.out.println("Bunday oy yo'q");
        }
        if (((day > 0) && (day < 32)) && (month > 0) && (month < 13))
            System.out.println(day + "." + month);
    }

}
