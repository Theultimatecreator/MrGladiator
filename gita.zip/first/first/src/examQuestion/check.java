package examQuestion;

import java.util.Scanner;

public class check {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a= "); double a = in.nextDouble();
        System.out.print("b= "); double b = in.nextDouble();
        System.out.print("c= "); double c = in.nextDouble();
        System.out.print("d= "); double d = in.nextDouble();
        if (a>0)
            System.out.println(a*a);
        else if (b>0)
            System.out.println(b*b);
        else if (c>0)
            System.out.println(c*c);
        else if (d>0)
            System.out.println(d*d);
        else
            System.out.println("0");
    }
}
