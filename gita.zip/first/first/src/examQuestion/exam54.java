package examQuestion;

import java.util.Scanner;

public class exam54 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String S = in.nextLine();
        int count = 0;
        for (int i = 0; i < S.length(); i++) {
            if (S.charAt(i) == ' ') {
                count++;
            }
        }
        if (count != 1) {
            S = S.substring(S.indexOf(" ") + 1, S.lastIndexOf(" "));
        } else
            S = "";
        System.out.print(S);
    }
}
