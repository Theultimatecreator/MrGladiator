package examQuestion;

import java.util.Scanner;

public class exam11 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("N = ");
        int N = in.nextInt();
        System.out.print("M = ");
        int M = in.nextInt();
        int i = 0;
        while (M <= N){
            N = N - M;
            i ++;
        }
        System.out.print("Butun = " + i + ", qoldiq = " + N);

    }
}
