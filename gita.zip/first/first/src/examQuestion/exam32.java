//package examQuestion;
//
//import java.util.Scanner;
//
//public class exam32 {
//    public static void main(String[] args) {
//        Scanner in = new Scanner(System.in);
//        System.out.println("sanalarni to'g'ri kiriting bo'lmasa chiqarmiyman");
//        System.out.println("yil=> oy=> sana=> ");
//        int y = in.nextInt(), m = in.nextInt(), d = in.nextInt();
//        PrevDate(d, m, y);
//    }
//
//    public static void PrevDate(int d, int m, int y) {
//        switch (d) {
//            case 1:
//                switch (m) {
//                    case 3: {
//                        if (exam32.IsLeapYear(y)) {
//                            d = 29;
//                            m = m - 1;
//                            y = y;
//                        } else {
//                            d = 28;
//                            m = m - 1;
//                            y = y;
//                        }
//                        break;
//                    }
//                    case 1:
//                        d = 31;
//                        m = 12;
//                        y = y - 1;
//                        break;
//                    case 2:
//                    case 4:
//                    case 6:
//                    case 9:
//                    case 11:
//                        d = 31;
//                        m = m - 1;
//                        y = y;
//                        break;
//                    case 5:
//                    case 7:
//                    case 8:
//                    case 10:
//                    case 12:
//                        d = 30;
//                        m = m - 1;
//                        y = y;
//                        break;
//                }
//            default:
//                d = d - 1;
//                m = m;
//                y = y;
//                break;
//        }
//        System.out.println("sana=> " + d + " oy=> " + m + " year=> " + y);
//
//    }
//}
