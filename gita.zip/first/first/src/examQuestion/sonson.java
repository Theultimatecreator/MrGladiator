package examQuestion;

import java.util.Scanner;

public class sonson {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int s = 0;
        for (int i = 21; i <=24 ; i++) {
            System.out.print(i + " ");
            s+=i;

        }
        System.out.println("yigindi = " + s);
    }
}
