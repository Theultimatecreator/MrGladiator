package examQuestion;

import java.util.Scanner;

public class exam3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("x = ");
        double x = in.nextDouble(), temp;
        System.out.print("y = ");
        double y = in.nextDouble();
        if (x > y) {
            temp = (x + y) / 2;
            x = 2 * x * y;
            y = temp;
            System.out.print("kichigi = " + y + " ga, kattasi = " + x + " ga ");
        } else if (x < y) {
            temp = (x + y) / 2;
            y = 2 * x * y;
            x = temp;
            System.out.print("kattasi = " + y + " ga "+"kichigi = " + x + " ga" );
        } else {
            System.out.print(x + ", " + y);
        }

    }
}
