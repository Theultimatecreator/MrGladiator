package examQuestion;

import java.util.Scanner;

public class exam12 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("n = ");
        int n = in.nextInt();
        System.out.println("1 - sonni kiriting: = ");
        int temp = in.nextInt();
        int min = temp;
        int max = temp;
        for (int i = 2; i <= n; i++) {
            System.out.println(i + "- sonni kiriting");
            temp = in.nextInt();
            if (min > temp) min = temp;
            else if (max < temp) max = temp;

        }
        System.out.printf("Min %d, Max %d", min, max);
    }
}
