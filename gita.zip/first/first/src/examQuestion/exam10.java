package examQuestion;

import java.util.Scanner;

public class exam10 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("A = ");
        int A = in.nextInt();
        System.out.print("B = ");
        int B = in.nextInt();
        int k = 1;
        for (int i = 1; i <= A && i <= B; i++) {
            if (A % i == 0 && B % i == 0){
                k = i;
            }
        }
        System.out.print("Eng katta umumiy bo'luvchisi = " +k);

    }

}
