package examQuestion;

import java.util.Scanner;

public class exam74 {
    static int count;
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int N1 = input.nextInt();
        int N2 = input.nextInt();
        int N3 = input.nextInt();
        System.out.print(Fib1(N1) + " ");
        System.out.print(Fib1(N2) + " ");
        System.out.print(Fib1(N3) + " ");
        System.out.print(count);

    }

    public static int Fib1(int n) {
        count++;
        if (n <= 2)
            return 1;
        return Fib1(n - 1) + Fib1(n - 2);
    }
    }

