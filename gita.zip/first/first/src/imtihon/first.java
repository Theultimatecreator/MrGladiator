package imtihon;

import java.util.Scanner;

public class first {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n = ");
        int N = in.nextInt();
        int i = 0, a = 0, b = 1, c = 0;
        while (N >= 1) {
            a = N % 10;
            if (a != 0) {
                c += a * b;
                b*=10;
            }

            N /= 10;
        }
        System.out.println("c = " + c);

    }
}
