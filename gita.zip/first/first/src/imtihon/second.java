package imtihon;

import java.util.Scanner;

public class second {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        System.out.println("2");
        System.out.println("3");
        System.out.println("5");
        System.out.println("7");
        for (int i = 8; i <= n; i++) {
            if (i % 2 != 0 && i % 3 != 0 && i % 5 != 0 && i % 7 != 0){
                System.out.println(i);
            }
        }
    }
}
