package imtihon;

import java.util.Scanner;

public class fifth {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = 0, b = 0, k = 0;
        int n = in.nextInt();
        a = in.nextInt();
        k = a;
        for (int i = 2; i <= n; i++) {
            b = in.nextInt();
            if (a == b) {
                a = in.nextInt();
                i++;
            } else {
                k = b;
            }
        }
        if (a != b && b != 0) {
            k = a;
        }
        System.out.println(k);

    }
}
