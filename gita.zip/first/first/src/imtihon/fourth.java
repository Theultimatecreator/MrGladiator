package imtihon;

import java.util.Scanner;

public class fourth {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt(), a = 0, b = 0;
        for (int i = 1; i <= 6; i++) {
            if (i % 2 == 0) {
                a += n % 10;
                n /= 10;
            } else {
                b += n % 10;
                n /= 10;
            }

        }
        if (a == b) {
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }
    }
}
