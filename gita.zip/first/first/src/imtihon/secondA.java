package imtihon;

import java.util.Scanner;

public class secondA {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        for (int i = 2; i <= n; i++) {
            double d = Math.floor(Math.sqrt(i));
            boolean bull = true;
            int k = 2;
            while (d >= k) {
                if (i % k == 0)
                    bull = false;
                k++;
            }
            if (bull)
                System.out.println(i);

        }
    }
}
