package shart_operatori;

import java.util.Scanner;

public class if22 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("x = ");
        int x = in.nextInt();
        System.out.print("y = ");
        int y = in.nextInt();
        if (x > 0 && y > 0) {
            System.out.print("birinchi chorak");
        } else if (x < 0 && y > 0) {
            System.out.print("ikkinchi chorak ");
        } else if (x < 0 && y < 0) {
            System.out.print("uchinchi chorak ");
        } else {
            System.out.print("To'rtinchi chorak ");
        }

    }
}
