package p_04_shart;

import java.util.Scanner;

public class if7 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        System.out.print("b = ");
        int b = in.nextInt();
        if (a > b){
            System.out.print("a = " + ( a = 1) + " va " + "b = " + (b = 2));
        }
        else
            System.out.print("a = " + ( a = 2) + " va " + "b = " + (b = 1));

    }
}
