package shart_operatori;

import java.util.Scanner;

public class if15 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("A = ");
        int A = in.nextInt();
        System.out.print("B = ");
        int B = in.nextInt();
        System.out.print("C = ");
        int C = in.nextInt();
        if (A + B > A + C)
            System.out.print("A = " + A + " B = " + B);
        else if (B + C > B + A)
            System.out.print("B = " + B + " C = " + C);
        else if (A + C > B + C)
            System.out.print("A = " + A + " C = " + C);
    }
}
