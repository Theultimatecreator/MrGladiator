package shart_operatori;

import java.util.Scanner;

public class if17 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("A = ");
        int A = in.nextInt();
        System.out.print("B = ");
        int B = in.nextInt();
        System.out.print("C = ");
        int C = in.nextInt();
        if (A < B && B < C || A > B && B > C)
            System.out.print("O'sish tartibida = " + 2 * A + " " + 2 * B + " " + 2 * C);
        else
            System.out.print("Ishorasi o'zgardi = " + (-A) + " " + (-B) + " " + (-C));
    }
}
