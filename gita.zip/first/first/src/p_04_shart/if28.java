package shart_operatori;

import java.util.Scanner;

public class if28 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("yil = ");
        int yil = in.nextInt();
        if (yil % 4 == 0) {
            if (yil % 100 != 0 && yil % 400 == 0)
            System.out.print("yilda " + (yil = 366) + " kun bor");
        } else {
            System.out.print("yilda " + (yil = 365) + " kun bor");
        }
    }
}
