package p_04_shart;

import java.util.Scanner;

public class if12 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        System.out.print("b = ");
        int b = in.nextInt();
        System.out.print("c = ");
        int c = in.nextInt();
        if (a > b && b > c || a == b){
            System.out.print("kichik son c = " + c);
        }else if (a > c && c > b || a == c){
            System.out.print("kichik son b = " + b);
        }else if (c > b && b > a){
            System.out.print("kichik son a = " + a);
        }

    }
}
