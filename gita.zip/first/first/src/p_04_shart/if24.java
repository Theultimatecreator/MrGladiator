package p_04_shart;

import java.util.Scanner;

public class if24 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("x = ");
        double x = in.nextDouble(), pi = 3.1415;
        if (x > 0) {
            System.out.print("f(x) = " + 2 * Math.sin(x * 180 / pi));
        } else {
            System.out.print("f(x) = " + (x - 6));
        }
    }
}
