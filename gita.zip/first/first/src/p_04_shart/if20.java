package shart_operatori;

import java.util.Scanner;

public class if20 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("A = ");
        int A = in.nextInt();
        System.out.print("B = ");
        int B = in.nextInt();
        System.out.print("C = ");
        int C = in.nextInt();
        if (A - B > A - C) {
            System.out.print("C nuqta yaqinroq " + (A - C));
        } else
            System.out.print("B nuqta yaqinroq = " + (A - B));
    }
}
