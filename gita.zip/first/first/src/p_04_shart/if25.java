package p_04_shart;

import java.util.Scanner;

public class if25 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("x = ");
        double x = in.nextDouble(), pi = 3.1415;
        if (x < -2 && x > 2) {
            System.out.print("f(x) = " + 2 * x);
        } else {
            System.out.print("f(x) = " + (-3 * x));
        }
    }
}
