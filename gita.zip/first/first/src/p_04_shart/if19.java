package shart_operatori;

import java.util.Scanner;

public class if19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("A = ");
        int A = in.nextInt();
        System.out.print("B = ");
        int B = in.nextInt();
        System.out.print("C = ");
        int C = in.nextInt();
        System.out.print("D = ");
        int D = in.nextInt();
        if (A == B && B == C && C != D)
            System.out.print("to'rinchi o'rinda = " + D);
        else if (A == B && B == D && D != C)
            System.out.print("Uchinchi o'rinda turibdi = " + C);
        else if (A == C && C == D && D != B)
            System.out.print("Ikkinchi o'rinda turibdi = " + B);
        else
            System.out.print("Birinchi o'rinda turibdi = " + A);
    }
}
