package p_04_shart;

import java.util.Scanner;

public class if8 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        System.out.print("b = ");
        int b = in.nextInt();
        if (a > b){
            System.out.print("a = " + a + " va " + "b = " + b);
        }
        else
            System.out.print("b = " + b + " va " + "a = " + a);

    }
}
