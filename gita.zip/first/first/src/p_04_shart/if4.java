package p_04_shart;

import java.util.Scanner;

public class if4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        System.out.print("b = ");
        int b = in.nextInt();
        System.out.print("c = ");
        int c = in.nextInt();
        if (a > 0 && b > 0 && c > 0) {
            System.out.print("Uchta musbat son bor ");
        } else if ((a > 0 && b > 0 && c < 0) || (a > 0 && b < 0 && c > 0) || (a < 0 && b > 0 && c > 0)) {
            System.out.print("ikkita musbat son bor");
        } else if ((a > 0 && b < 0 && c < 0) || (a < 0 && b > 0 && c < 0) || (a < 0 && b < 0 && c > 0)) {
            System.out.print("bitta musbat son bor");
        }
    }
}
