package shart_operatori;

import java.util.Scanner;

public class if18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("A = ");
        int A = in.nextInt();
        System.out.print("B = ");
        int B = in.nextInt();
        System.out.print("C = ");
        int C = in.nextInt();
        if (A == B && B != C)
            System.out.print("Uchinchi o'rinda turibdi = " + C);
        else if (A == C && C != B)
            System.out.print("Ikkinchi o'rinda turibdi = " + B);
        else
            System.out.print("birinchi o'rinda turibdi = " + A);
    }
}
