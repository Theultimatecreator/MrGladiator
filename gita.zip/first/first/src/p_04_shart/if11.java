package p_04_shart;

import java.util.Scanner;

public class if11 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        System.out.print("b = ");
        int b = in.nextInt();
        if (a != b && a > b) {
            System.out.print("a = " + a + " va " + "b = " + a);
        } else if (a == b)
            System.out.print("b = " + (b = 0) + " va " + "a = " + (a = 0));

    }
}
