package shart_operatori;

import java.util.Scanner;

public class if30 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        if (a >= 10 && a <= 99 && a % 2 == 0) {
            System.out.print("Berilgan son ikki xonali juft ->" + a);
        } else if (a >= 100 && a <= 999 && a % 2 == 0) {
            System.out.print("Berilgan son uch xonali juft ->" + a);
        } else if (a >= 1 && a <= 9 && a % 2 == 0) {
            System.out.print("Berilgan son bir xonali juft ->" + a);
        } else
            System.out.print("Berilgan son juft emas ->" + a);
    }
}
