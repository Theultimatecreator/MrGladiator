package p_04_shart;

import java.util.Scanner;

public class if6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        System.out.print("b = ");
        int b = in.nextInt();
        if (a > b){
            System.out.print(a + " katta " + b + " dan");
        }else
            System.out.print(b + " katta " + a + " dan");
    }
}
