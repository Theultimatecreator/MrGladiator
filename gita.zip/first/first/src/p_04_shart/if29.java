package shart_operatori;

import java.util.Scanner;

public class if29 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        if (a > 0 && a % 2 == 1) {
            System.out.print("Musbat toq son = " + a);
        } else if (a < 0 && a % 2 == 0) {
            System.out.print("Manfiy juft son = " + a);
        } else {
            System.out.print("Son nolga teng = " + a);
        }
    }
}
