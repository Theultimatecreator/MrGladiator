package p_04_shart;

import java.util.Scanner;

public class if10 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        System.out.print("b = ");
        int b = in.nextInt();
        if (a != b) {
            System.out.print("a = " + (a + b) + " va " + "b = " + (a + b));
        } else if(a == b)
            System.out.print("b = " + (b = 0) + " va " + "a = " + (a = 0));

    }
}
