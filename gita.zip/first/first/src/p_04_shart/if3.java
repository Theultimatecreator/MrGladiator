package p_04_shart;

import java.util.Scanner;

public class if3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        if (a > 0){
            System.out.print("birga oshdi = " + (++a));
        }
        else if(a < 0) {
            System.out.print("a = " + (a - 2));
        }
        else
            System.out.print("a = " + (a + 10));
    }
}
