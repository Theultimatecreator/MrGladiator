package p_03_bolean;

public class bool29 {
}
