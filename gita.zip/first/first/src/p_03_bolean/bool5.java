package p_03_bolean;

import java.util.Scanner;

public class bool5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        System.out.print("b = ");
        int b = in.nextInt();
        boolean natija = a >= 0 || b < -2;
        System.out.print("Natija = " + natija);
    }
}
