package p_03_bolean;

import java.util.Scanner;

public class bool8 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int A = in.nextInt();
        System.out.print("b = ");
        int B = in.nextInt();
        boolean natija = A % 2 == 1 && B % 2 == 1 ;
        System.out.print("Natija = " + natija);
    }
}
