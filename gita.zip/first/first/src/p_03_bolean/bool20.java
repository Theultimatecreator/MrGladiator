package p_03_bolean;

import java.util.Scanner;

public class bool20 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int A = in.nextInt();
        //123
        //A%10=3
        //A/10%10=2
        //A/100=1
        boolean natija = ((A % 10 != A / 10 % 10) && (A / 10 % 10 != A / 100) && (A % 10 != A / 100));
        System.out.print("natija = " + natija);
    }
}
