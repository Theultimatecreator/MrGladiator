package p_03_bolean;

import java.util.Scanner;

public class bool34 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int x = in.nextInt();
        int y = in.nextInt();
        boolean natija = (x + y) % 2 != 0;
        System.out.println("natija = " + natija);
    }
}
