package p_03_bolean;

import java.util.Scanner;

public class bool16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int A = in.nextInt();

        boolean natija = A >= 10 && A <= 99 && A % 2 == 0;
        System.out.print("Natija = " + natija);
    }
}
