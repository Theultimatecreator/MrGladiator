package p_03_bolean;

import java.util.Scanner;

public class bool18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int A = in.nextInt();
        System.out.print("b = ");
        int B = in.nextInt();
        System.out.print("c = ");
        int C = in.nextInt();
        boolean natija = (A == B) || (B == C) || (A == C);
        System.out.print("Natija = " + natija);
    }
}
