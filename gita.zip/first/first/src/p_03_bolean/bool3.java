package p_03_bolean;

import java.util.Scanner;

public class bool3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        boolean natija = a % 2 == 0;
        System.out.print("Natija = " + natija);
    }
}
