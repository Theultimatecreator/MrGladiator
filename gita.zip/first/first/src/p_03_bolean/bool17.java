package p_03_bolean;

import java.util.Scanner;

public class bool17 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int A = in.nextInt();

        boolean natija = A >= 100 && A <= 999 && A % 2 == 1;
        System.out.print("Natija = " + natija);
    }
}
