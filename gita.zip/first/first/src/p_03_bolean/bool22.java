package p_03_bolean;

import java.util.Scanner;

public class bool22 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int A = in.nextInt();

        boolean natija =(A / 100f) < (A / 10f % 10) && (A / 10f % 10) < (A % 10) || (A / 100f) > (A / 10f % 10) && (A / 10f % 10) > (A % 10);
        System.out.print("Natija = " + natija);
    }
}
