package p_03_bolean;

import java.util.Scanner;

public class bool7 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        int a = in.nextInt();
        System.out.print("b = ");
        int b = in.nextInt();
        System.out.print("c = ");
        int c = in.nextInt();
        boolean natija = a <= b && b <= c;
        System.out.print("Natija = " + natija);
    }
}
