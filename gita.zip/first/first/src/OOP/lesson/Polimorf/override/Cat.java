package OOP.lesson.Polimorf.override;

public class Cat extends Animal {
    public void voice(){
        System.out.println("Meow");
    }
}
