package OOP.lesson.Polimorf.override;

public class Dog extends Animal{
    public void voice(){
        System.out.println("woof");
    }
}
