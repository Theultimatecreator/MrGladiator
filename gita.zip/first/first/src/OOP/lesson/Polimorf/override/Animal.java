package OOP.lesson.Polimorf.override;

public class Animal {
    int age;
    String color;

    public void voice(){
        System.out.println("Hayvon ovozi");
    }
}
