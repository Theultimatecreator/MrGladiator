package OOP.lesson.Polimorf.A;

import OOP.lesson.Polimorf.override.Cat;

public class Main {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        System.out.println("add(int a, int b) = " + calculator.add(4, 8));
        System.out.println("add(int a, int b, int c) = " + calculator.add(4, 5, 9));
        System.out.println("add(double a, double b) = " + calculator.add(2.3, 7.5));
        String s = calculator.add(3, 5, 6d);
        System.out.println(s);
        System.out.println("add(int a, int b, double c) = " + calculator.add(2, 4, 6.7));
    }
}
