package OOP.lesson.Polimorf;

public class Main {
    public static void main(String[] args) {

        Calculator calculator = new Calculator();
        System.out.println("add(int a, int b) = " + calculator.add(4, 5));
        System.out.println("add(int a, int b, int c) = " + calculator.add(4, 5, 6));
        System.out.println("add(double a, double b) = " + calculator.add(2.3, 6d));
        String s = calculator.add(4, 5, 6.2);
        System.out.println(s);

    }
}
