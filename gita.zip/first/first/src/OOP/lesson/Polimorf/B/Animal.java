package OOP.lesson.Polimorf.B;

public class Animal {

     public void voice(){
         System.out.println("hayvon ovozi");
     }
}
