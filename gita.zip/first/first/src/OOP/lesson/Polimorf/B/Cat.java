package OOP.lesson.Polimorf.B;

public class Cat extends Animal {
    public void voice() {
        System.out.println("Meow");
    }
}
