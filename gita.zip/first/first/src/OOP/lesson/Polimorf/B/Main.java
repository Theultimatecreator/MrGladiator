package OOP.lesson.Polimorf.B;

public class Main {
    public static void main(String[] args) {
        Animal animal = new Animal();
        animal.voice();

        Dog dog = new Dog();
        dog.voice();

        Cat cat = new Cat();
        cat.voice();
    }
}
