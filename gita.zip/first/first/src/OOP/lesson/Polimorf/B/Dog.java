package OOP.lesson.Polimorf.B;

public class Dog extends Animal{
    public void voice(){
        System.out.println("Woof");
    }
}
