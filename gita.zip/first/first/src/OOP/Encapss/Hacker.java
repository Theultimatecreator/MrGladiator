package OOP.Encapss;

public class Hacker {
    public static void main(String[] args) {
        Account acc = new Account();
        acc.setAccountBalance(100);
        acc.deposit(100);
        System.out.println("Accountda " + acc.getAccountBalance());
    }
}
