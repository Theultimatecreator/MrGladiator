package OOP.Encapss;

public class Dog {
    private String name ;
    private int age ;
    private String color ;
    public Dog setperson(String name,int age ,String color) {

        this.name = name ;
        this.age = age ;
        this.color = color ;
        return this ;
    }

    public void Bobek() {

        System.out.println("A dog named " + this.name+" whose age is"+this.age+" the fair color is "+this.color);
    }
}
