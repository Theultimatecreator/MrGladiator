package OOP.Encapss;

public class Animan {
    public static void main(String[] args) {
        Dog dog1 = new Dog();

        dog1.setperson("hu_zi", 19 ,"white");

        dog1.Bobek();
    }
}
