package OOP.Encapss;

public class Main {
    public static void main(String[] args) {
        Student student = new Student();
        student.setName("Azamat");
        student.setPhone("+998977454545");
        student.setAge(26);

        System.out.println("Student's name : " + student.getName());
        System.out.println("Student's phone : " + student.getPhone());
        System.out.println("Student's age : " + student.getAge());
    }
}
