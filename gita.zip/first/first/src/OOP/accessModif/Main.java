package OOP.accessModif;

public class Main {
    public static void main(String[] args) {
        Pen pen = new Pen();
        pen.color = "red";
    }
}
