package OOP.accessModif;

public class Pen {
    private int inq;
    String color;//deafult
    public boolean button;

    void printInq(){
        System.out.println(inq);
    }
}
