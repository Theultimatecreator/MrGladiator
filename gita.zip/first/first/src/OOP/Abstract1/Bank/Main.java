package OOP.Abstract1.Bank;

public class Main {
    public static void main(String[] args) {
        Bank bank = new KapitalBank("KapitalBank");
        bank.kredit();
    }
}

