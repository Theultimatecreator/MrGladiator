package OOP.Abstract1;

public class Ghost extends Sayt {
    @Override
    public void userUrl() {
        super.userUrl();
        System.out.println("Hush kulibsiz");
    }

    @Override
    public void adminUrl() {
        super.adminUrl();
        System.out.println("Sizda bunday huquq yo'q");
    }


}
