package OOP.Abstract1;

public class Admin extends Sayt{
    @Override
    public void userUrl() {
        super.userUrl();
        System.out.println("Admen Bo'limi");
    }

//    @Override
//    public void getSayt() {
//        System.out.println(name);
//    }
}
