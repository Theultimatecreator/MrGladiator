package OOP.Abstract1;

public class Main {
    public static void main(String[] args) {
        Admin admin = new Admin();
        admin.adminUrl();

        Ghost ghost = new Ghost();
        ghost.userUrl();
        ghost.adminUrl();
        Sayt sayt = new Sayt();
        sayt.adminUrl();


    }
}
