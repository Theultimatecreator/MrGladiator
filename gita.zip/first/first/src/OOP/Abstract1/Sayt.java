package OOP.Abstract1;

public  class Sayt {
//    Abstract kalsdan voris olayotgan paytimizda voris olishga majbur qiladi
//    Abstract klasdan voris olish mumkin lekin obekt olib  bo'lmaydi
//    Abstract method tana qismga ega bo'lmaydi

    String name;

    public void userUrl(){
        System.out.println("Oddiy foydalanuvchi uchun");
    }

    public void adminUrl(){
        System.out.println("Admin uchun");
    }

}
