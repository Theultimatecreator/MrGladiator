package OOP;

public class Car {
    //    Parametres::::
    String model;
    String color;
    String number;
    int year;
    int maxSpeed;

    double km;
    boolean state;

    // Constructors
//    Default No-argument   Parametrized constructor
//    Car(){
//       Default constructor
//    }

    //    no-argument constructor
    Car() {
        year = 2020;
        maxSpeed = 200;
        km = 100;
    }

    //    Parametrized constructor
    Car(String model, String color, String number, int year, int maxSpeed, double km, boolean state) {
        this.model = model;
        this.color = color;
        this.number = number;
        this.year = year;
        this.maxSpeed = maxSpeed;
        this.km = km;
        this.state = state;

    }

    //    Methods
    void startOn() {
        state = true;
        System.out.println("Moshina o't oldi");
    }

    void startOf() {
        state = false;
        System.out.println("Moshina o'chdi");
    }

    void drive(double distance) {
        km += distance;
        System.out.println("Moshina " + km + " masofani bosib o'tti ");
    }

}
