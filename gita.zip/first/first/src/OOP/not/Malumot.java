package OOP.not;

public class Malumot {
    String name;
    String surname;
    String lastname;
    String phoneNumber;
    String date;
    int birthDate;

}
