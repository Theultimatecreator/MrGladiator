package OOP.not;

import java.util.ArrayList;
import java.util.Scanner;

public class Daftarcha {
    Scanner in = new Scanner(System.in);
    ArrayList<Malumot> yozuvlar = new ArrayList<>();


    void qoshish() {
        Malumot yangiMalumot = new Malumot();
        System.out.println("Ism kiriting: ");
        yangiMalumot.name = in.nextLine();
        System.out.println("Familiya kiriting: ");
        yangiMalumot.surname = in.nextLine();
        System.out.println("Otasining ismini kiriting: ");
        yangiMalumot.lastname = in.nextLine();
        System.out.println("Telefon raqamini kiriting: ");
        yangiMalumot.phoneNumber = in.nextLine();
        System.out.println("sanani kiriting: ");
        yangiMalumot.date = in.nextLine();
        System.out.println("tug'ilgan sanani kiriting: ");
        yangiMalumot.birthDate = in.nextInt();

        yozuvlar.add(yangiMalumot);
    }

    void yozuvlarniOqish() {
        System.out.println("№  |  name   |   surname   |  lastname   |   phoneNumber   |  date   |   birthDate  ");
        for (int x = 0; x < yozuvlar.size(); x++) {
            Malumot i = yozuvlar.get(x);
            System.out.println(x + " " + i.name + " " + i.surname + " " + i.lastname + " " + i.phoneNumber + " " + i.date + " " + i.birthDate);
        }
    }

    void ochirish() {
        yozuvlarniOqish();
        System.out.println("qaysi nomerdagi yozuvni o'chirmoqchisiz ");
        int n = in.nextInt();
        yozuvlar.remove(n);
    }

}
