package OOP.not;

import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Daftarcha daftarcha = new Daftarcha();
        System.out.println("Yon daftarcha dasturiga xush kelibsiz!");

        takror:
        while (true) {
            System.out.println("Amalni tanlang:");
            System.out.println("1 - yozuv qo'shish");
            System.out.println("2 - yozuv o'qish");
            System.out.println("3 - yozuv o'chirish");
            System.out.println("0 - dasturdan chiqish");

            switch (in.nextInt()) {
                case 1 -> daftarcha.qoshish();
                case 2 -> daftarcha.yozuvlarniOqish();
                case 3 -> daftarcha.ochirish();
                case 0 -> {
                    break takror;
                }
            }
        }

        daftarcha.qoshish();
        daftarcha.yozuvlarniOqish();
        daftarcha.ochirish();
    }
}
