package OOP.Practice;

public class Main {
    public static void main(String[] args) {
        Car car1 = new Car();
        car1.color = "red";
        car1.maxSpeed = 230;
        car1.km = 120;
        car1.model = "Nexia";
        car1.number = "A 01 230 AA";
        car1.year = 2020;
        car1.state = false;


        System.out.println("********car1**********");
        car1.startOn();
        System.out.println("model = " + car1.model);
        System.out.println("number = " + car1.number);
        System.out.println("color = " + car1.color);
        System.out.println("maxSpeed = " + car1.maxSpeed);
        System.out.println("km = " + car1.km);
        System.out.println("year = " + car1.year);
        System.out.println("state = " + car1.state);
        System.out.println();
        System.out.println();

        Car car2 = new Car();
        car2.color = "black";
        car2.maxSpeed = 250;
        car2.km = 220;
        car2.model = "Matiz";
        car2.number = "A 01 290 AA";
        car2.year = 2018;
        car2.state = false;

        System.out.println("********car2**********");
        car2.startOn();
        System.out.println("model = " + car2.model);
        System.out.println("number = " + car2.number);
        System.out.println("color = " + car2.color);
        System.out.println("maxSpeed = " + car2.maxSpeed);
        System.out.println("km = " + car2.km);
        System.out.println("year = " + car2.year);
        car2.drive(123);
        System.out.println("state = " + car2.state);
    }
}
