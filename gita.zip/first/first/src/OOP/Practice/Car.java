package OOP.Practice;

public class Car {
    String model;
    String color;
    String number;
    int year;
    double km;
    int maxSpeed;
    boolean state;

    void startOn() {
        state = true;
        System.out.println("Moshina o't olgan!!");
    }

    void startOff() {
        state = false;
        System.out.println("Moshina o'chdi!!");
    }

    void drive(double distance) {
        km += distance;
        System.out.println("Moshina " + distance + " masofani bosib o'tti ");
    }

}
