package OOP.Practice.Bankamat;

public class Card {
    private String name;
    private String id;
    private String date;
    private String owner;
    private int password;
    private double money;

    public Card() {
    }

    public Card(String name, String id, String date, String owner, int password, double money) {
        this.name = name;
        this.id = id;
        this.date = date;
        this.owner = owner;
        this.password = password;
        this.money = money;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public int getPassword() {
        return password;
    }

    public void setPassword(int password) {
        this.password = password;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

}