package OOP.Practice.Bankamat;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Card card1 = new Card("Aloqabank", "8600124578951635", "09/25", "Xayriddinov Davron",
                1111, 29568.12);
        Scanner intScanner = new Scanner(System.in);
        Scanner strScanner = new Scanner(System.in);
        while (true){
            System.out.println("=== Menu ===");
            System.out.println("Tilni tanlang:\n1. O'zbek tili\n2.Rus tili\n3.Ingliz tili\n0.Plastik kartani " +
                    "chiqarish");
            int input;
            input = intScanner.nextInt();
            switch (input){
                case 1:
                    System.out.println("O'zbek tili");
                    mainMenu(card1, intScanner);
                    break;
                case 2:
                    System.out.println("Rus tili");
                    System.out.println("Kechirasiz rus tili hali yo'q");
                    break;
                case 3:
                    System.out.println("Ingliz tili");
                    System.out.println("Kechirasiz ingliz tili hali yo'q");
                    break;
                case 0:
                    System.out.println("Raxmat");
                    break;
                default:
                    System.out.println("Menuga qarang!!!");
                    break;
            }
        }


      /*card1.setId("8600124578951635");
        System.out.println(card1.getId().substring(0,4) +
                " **** **** " + card1.getId().substring(12,16));*/
    }

    private static void mainMenu(Card card1, Scanner intScanner) {
        Scanner strScanner = new Scanner(System.in);
        while (true){
            System.out.println("Parolni kiriting: ");
            int password = intScanner.nextInt();
            if (password == card1.getPassword()){
                while (true){
                    System.out.println("1.Balansni ko'rish\n2.Pul yechish\n3.Pul o'tkazish\n4.Parolni o'zgartirish\n" +
                            "0.Ortga qaytish");
                    int input;
                    input= intScanner.nextInt();
                    switch (input){
                        case 1:
                            System.out.println("Sizning balansingiz: ");
                            System.out.println(card1.getMoney() + " so'm");

                            break;
                        case 2:
                            drawMoney(card1, intScanner);
                            break;
                        case 3:
                            System.out.println("Karta idsini kiriting: ");
                            String cardId;
                            cardId = strScanner.nextLine();
                            if(cardId.length() == 16 ){
                                System.out.println("Qancha pul o'tkazasiz: ");
                                double pul;
                                pul = intScanner.nextDouble();
                                if(pul < card1.getMoney() * 1.01){
                                    card1.setMoney(card1.getMoney() - pul*1.01);
                                    System.out.println("Pul yuborildi. Hisobingizda: " + card1.getMoney());
                                }
                            }
                            break;
                        case 4:
                            System.out.println("Yangi parolni kiriting: ");
                            int newpassword;
                            int newpassword2;
                            newpassword = intScanner.nextInt();
                            System.out.println("Yangi parolni qayta kiriting: ");
                            newpassword2 = intScanner.nextInt();
                            String check = String.valueOf(newpassword);
                            if(newpassword==newpassword2 && check.length() == 4){
                                card1.setPassword(newpassword);
                                System.out.println("Parol o'zgardi");
                            }
                            else {
                                System.out.println("Parol to'g'ri kiritilmadi");
                            }
                            break;
                        case 0:
                            mainMenu(card1,intScanner);
                            break;

                    }
                }
            }
            else {
                System.out.println("Parol xato: ");
            }
        }
    }

    private static void drawMoney(Card card1, Scanner intScanner) {
        System.out.println("Qancha pul yechmoqchisiz: ");
        double pul;
        pul = intScanner.nextDouble();
        if(pul*1.01 < card1.getMoney()){
            card1.setMoney(card1.getMoney() - pul *1.01);
            System.out.println("Sizning hisobingizdan " + pul *1.01 + " so'm pul yechildi");
        }
        else {
            System.out.println("Balansingizda mablag' yetarli emas!!!");
        }
    }
}
