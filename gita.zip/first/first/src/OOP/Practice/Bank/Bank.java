package OOP.Practice.Bank;

public class Bank {
    private String name;
    private String accounNum;
    private double balance;

    Client [] clients = new Client[1000];
    int count;

    public String getName() {
        return name;
    }

    public void showClient(){
        for (int i = 0; i < count; i++) {
            System.out.println(clients[i].getClientName());
        }
    }

    public void addClient(Client client){
        clients[count++] = client;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccounNum() {
        return accounNum;
    }

    public void setAccounNum(String accounNum) {
        this.accounNum = accounNum;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }


    public void depositBank(double deposit) {
        balance += deposit;
        System.out.println("Bankda " + balance + " so'm pul qo'yildi!");
    }

}
