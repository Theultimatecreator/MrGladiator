package OOP.Practice.Bank;

public class Hacker {
    Client client = new Client();
    Bank bank = new Bank();
}
