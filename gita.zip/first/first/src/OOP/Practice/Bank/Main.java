package OOP.Practice.Bank;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Bank bank = new Bank();
        Client client = new Client();
        bank.setName(in.next());
        client.setClientName(in.next());
        bank.setBalance(6000000);
        bank.setAccounNum("AA123AA");
        client.setClientBalance(4500000);
        client.setClientId("132aa");

        System.out.println("Bank name = " + bank.getName());
        System.out.println("Bank account = " + bank.getAccounNum());
        System.out.println("Bank balance = " + bank.getBalance());
        System.out.println("client clientName = " + client.getClientName());
        System.out.println("client balance = " + client.getClientBalance());
        System.out.println("client balance = " + client.getClientBalance());
        System.out.println("client clientId = " + client.getClientId());
        bank.depositBank(in.nextDouble());
        client.depositClient(in.nextDouble());
        bank.addClient(client);
        bank.showClient();
    }
}
