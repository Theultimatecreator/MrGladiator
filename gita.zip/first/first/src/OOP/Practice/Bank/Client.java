package OOP.Practice.Bank;

public class Client {
    private String clientName;
    private String clientId;
    private double clientBalance;

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public double getClientBalance() {
        return clientBalance;
    }

    public void setClientBalance(double clientBalance) {
        this.clientBalance = clientBalance;
    }

    public void depositClient(double deposit) {
        clientBalance += deposit;
        System.out.println("Client bankdan " + deposit + " so'm qarz oldi ");
        System.out.println("Client balanci " + clientBalance + " so'm bo'ldi ");

    }
}
