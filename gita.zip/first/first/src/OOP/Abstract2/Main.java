package OOP.Abstract2;

public class Main {
    public static void main(String[] args) {
        Admin admin = new Admin();
        admin.adminUrl();
        admin.userUrl();

        Ghost ghost = new Ghost();
        ghost.adminUrl();
        ghost.userUrl();


    }
}
