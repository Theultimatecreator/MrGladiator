package OOP.Abstract2;

public class Ghost extends Sayt{
    @Override
    public void userUrl() {
        super.userUrl();
        System.out.println("Hush kelibsiz");
    }

    @Override
    public void adminUrl() {
        super.adminUrl();
        System.out.println("Sizda bunday huquq yo'q");
    }
    public void getSayt() {
        System.out.println(name);
    }
}
