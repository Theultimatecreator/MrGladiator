package OOP.Abstract2;

public class Admin extends Sayt {
    @Override
    public void adminUrl() {
        super.adminUrl();
        System.out.println("Admin paneliga hush kelibsiz!!");
    }

    public void getSayt() {
        System.out.println(name);
    }
}
