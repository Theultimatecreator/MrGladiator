package OOP.Abstract2;

public abstract class Sayt {
//    Abstract methodlarda tana qism bo'lmaydi
//    Abstract classdan voris olish mumkin lekin obekt yaratib bo'lmaydi

    String name;

    public void userUrl() {
        System.out.println("Oddiy foydalanuvchilar uchun !!!");
    }

    public void adminUrl() {
        System.out.println("Faqat admin uchun!!");
    }
    public abstract void getSayt();
}
