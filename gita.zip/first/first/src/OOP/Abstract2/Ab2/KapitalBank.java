package OOP.Abstract2.Ab2;

public class KapitalBank extends Bank {
    KapitalBank(String name) {
        super(name);
    }

    @Override
    public void kredit() {
        System.out.println("Kredit foizi 21%");
    }
}
