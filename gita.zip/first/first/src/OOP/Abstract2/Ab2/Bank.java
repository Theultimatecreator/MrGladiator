package OOP.Abstract2.Ab2;

public abstract class Bank {
    String name;

    Bank(String name) {
        this.name = name;
    }

    public abstract void kredit();

    public String getName() {
        return name;
    }
}
