package OOP.Abstract2.Ab2;

public class Main {
    public static void main(String[] args) {
        Bank bank = new KapitalBank("Kapitalbank");
        bank.kredit();
    }
}
