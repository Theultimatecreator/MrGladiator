package OOP.SariqBola;

public class Wolf implements Predator {
    @Override
    public void hunt() {
        System.out.println("Bo'ri ov qiladi");
    }
}
