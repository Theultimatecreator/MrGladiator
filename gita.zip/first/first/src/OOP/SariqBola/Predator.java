package OOP.SariqBola;

public interface Predator {
    void hunt();
}
