package OOP.SariqBola;

public class Rabbit implements Prey {
    @Override
    public void run() {
        System.out.println("Quyon qoch!");
    }
}
