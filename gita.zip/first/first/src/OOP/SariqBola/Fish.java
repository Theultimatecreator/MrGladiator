package OOP.SariqBola;

public class Fish implements Predator, Prey{
    @Override
    public void hunt() {
        System.out.println("katta baliq ov qiladi");
    }

    @Override
    public void run() {
        System.out.println("kichkina baliq o'lja bo'ladi");
    }
}
