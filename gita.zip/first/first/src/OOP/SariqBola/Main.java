package OOP.SariqBola;

public class Main {
    public static void main(String[] args) {
        System.out.println("Fish");
        Fish fish = new Fish();
        fish.hunt();
        fish.run();
        System.out.println("Quyon");
        Rabbit rabbit = new Rabbit();
        rabbit.run();
        System.out.println("Wolf");
        Wolf wolf = new Wolf();
        wolf.hunt();
    }
}
