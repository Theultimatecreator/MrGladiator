package OOP.SariqBola;

public interface Prey {
    void run();
}
