package OOP.ArrayLists;

import java.util.ArrayList;
import java.util.Scanner;

public class ArraysLists1 {
    public static void main(String[] args) {
        ArrayList<String> cars = new ArrayList<String>();
        cars.add("Matiz");
        cars.add("Spark");
        cars.add("Malibu");
        cars.add("Nexia");
        cars.add("Spark");
        System.out.println(cars);
        System.out.println(cars.get(0));
        cars.set(0, "Toyotta");
        System.out.println(cars);
        cars.add("Opel");
        System.out.println(cars);

        System.out.println("for ");
        for (int i = 0; i < cars.size(); i++) {
            System.out.print(cars.get(i) + " ");
        }
        System.out.println("Spark elementi bori");
        for (int i = 0; i < cars.size(); i++) {
            if (cars.get(i) == "Spark")
                System.out.print(cars.get(i) + " ");
        }
        System.out.println("sparkni remove");
        for (int i = 0; i < cars.size(); i++) {
            if (cars.get(i) == "Spark")
                System.out.print(cars.remove(i) + " ");
        }
        System.out.println("spark o'chirildi");
        System.out.println(cars);

//        for each
        System.out.println("for each");
        for (String i : cars) {
            System.out.print(i + " ");
        }


    }
}

class arraylistInteger {
    public static void main(String[] args) {
        ArrayList<Integer> myNumbers = new ArrayList<Integer>();
        myNumbers.add(10);
        myNumbers.add(15);
        myNumbers.add(20);
        myNumbers.add(25);
        myNumbers.add(20);

        for (int i = 0; i < myNumbers.size(); i++) {
            if (myNumbers.get(i) == 20){
                myNumbers.remove(i);

                i--;
            }
        }
        System.out.print(myNumbers + " ");
    }
}


class array2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        ArrayList<Integer> num = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            num.add(in.nextInt());
        }
        for (int i = 0; i < num.size(); i++) {
            System.out.print(num.get(i) + " ");
        }
    }
}