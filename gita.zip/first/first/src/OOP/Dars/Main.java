package OOP.Dars;

public class Main {
    public static void main(String[] args) {
        PhpTeacher pteacher = new PhpTeacher();
        JavaTeacher jteacher = new JavaTeacher();
        pteacher.whatDo();
        pteacher.show();
        System.out.println("*******************");
        jteacher.whatDo();
        jteacher.show();
    }
}
