package OOP.Dars;

public class Teacher {
    int age;
    String name;
    String surname;
    int workExperience;
    String course;



    public void show(){
        System.out.println("O'qituvchi ismi : " + this.name);
        System.out.println("O'qituvchi familiyasi : " + this.surname);
        System.out.println("O'qituvchi kursi : " + this.course);
        System.out.println("O'qituvchi ish tajribasi : " + this.workExperience);
    }
}
