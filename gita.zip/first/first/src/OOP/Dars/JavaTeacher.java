package OOP.Dars;

public class JavaTeacher extends Teacher{
    public JavaTeacher(){
        this.name = "Abdulboriy";
        this.surname = "Olimov";
        this.age = 16;
        this.workExperience = 3;


    }

    public void whatDo(){
        System.out.println("Javadan dars beradi!!!");
    }
}
