package OOP.Dars;

public class PhpTeacher extends Teacher {
    public PhpTeacher(){
        this.name = "Asqar";
        this.surname = "Aliboyev";
        this.age = 29;
        this.course = "PHP";
        this.workExperience = 6;

    }

    public void whatDo(){
        System.out.println("PHP dan dars beradi!!!");
    }
}
