package OOP.Interface;

public class Fish implements Prey, Predator {
    @Override
    public void hunt() {
        System.out.println("kichkina baliqlarni yeydi");
    }

    @Override
    public void run() {
        System.out.println("kichkina bo'lgani uchun qochadi");
    }
}
