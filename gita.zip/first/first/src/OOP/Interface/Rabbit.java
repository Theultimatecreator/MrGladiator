package OOP.Interface;

public class Rabbit implements Prey {
    @Override
    public void run() {
        System.out.println("quyon qochadi");
    }
}
