package OOP.Interface;

public interface Predator {
 void hunt();
}
