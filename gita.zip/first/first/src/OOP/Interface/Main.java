package OOP.Interface;

public class Main {
    public static void main(String[] args) {
        Rabbit rabbit = new Rabbit();
        rabbit.run();
        Wolf wolf = new Wolf();
        wolf.hunt();
        Fish fish = new Fish();
        fish.hunt();
        fish.run();
    }
}
