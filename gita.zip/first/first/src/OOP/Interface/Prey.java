package OOP.Interface;

public interface Prey {
    void run();
}
