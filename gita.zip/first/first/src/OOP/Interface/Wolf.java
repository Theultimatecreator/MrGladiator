package OOP.Interface;

public class Wolf implements Predator {
    @Override
    public void hunt() {
        System.out.println("ov qiladi");
    }
}
