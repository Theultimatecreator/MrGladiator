package OOP.Polimorfizm.OverRide;

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.voice();
        Cat cat = new Cat();
        cat.voice();


        Animal animal = new Animal();
        animal.voice();
    }
}
