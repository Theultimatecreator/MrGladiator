package OOP.Polimorfizm.OverRide;

public class Dog extends Animal {
    public void voice() {
        System.out.println("Woof");
    }
}
