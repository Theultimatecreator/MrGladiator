package OOP.Polimorfizm.Shape;

public class Shape {
    double a;
    double b;
    double c;
    double h;
    double yuza;
    static double pm;

    public static double perimetr(double a, double b){
        pm = (a + b) * 2;
        return pm;
    }
    public static double perimetr(double a, double b, double c){
        pm = a + b + c;
        return pm;
    }

}
