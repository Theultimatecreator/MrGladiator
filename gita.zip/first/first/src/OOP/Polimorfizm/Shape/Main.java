package OOP.Polimorfizm.Shape;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Shape shape = new Shape();
        System.out.println("qaysi shakilni tanlaysiz!!!");
        int n = in.nextInt();
        switch (n) {
            case 1 -> {
                System.out.println("Siz to'g'ri to'rtburchakni tanladingiz!");
                double a = in.nextDouble();
                double b = in.nextDouble();
                System.out.println(Shape.perimetr(a, b));
            }
            case 2 -> {
                System.out.println("Siz uchburchakni tanladingiz!");
                double a = in.nextDouble();
                double b = in.nextDouble();
                double c = in.nextDouble();
                System.out.println(Shape.perimetr(a, b, c));
            }
        }
    }
}
