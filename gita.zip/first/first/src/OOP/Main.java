package OOP;

public class Main {
    public static void main(String[] args) {
        Car car1 = new Car();
//        car1.km = 100;
        car1.color = "Black";
        car1.model = "Tracker";
//        car1.maxSpeed = 220;
        car1.number = "01 A234AA";
//        car1.year = 2020;

        Car car2 = new Car();
//        car2.year = 2019;
        car2.number = "10 A234SS";
//        car2.maxSpeed = 240;
        car2.model = "Malibu";
        car2.color = "White";
//        car2.km = 1500;
        car2.state = true;

        System.out.println("******************car1****************");
        System.out.println("model = " + car1.model);
        System.out.println("number = " + car1.number);
        System.out.println("year = " + car1.year);
        System.out.println("color = " + car1.color);
        System.out.println("state = " + car1.state);
        System.out.println("km = " + car1.km);
        System.out.println("maxSpeed = " + car1.maxSpeed);

        System.out.println("******************car2****************");
        System.out.println("model = " + car2.model);
        System.out.println("number = " + car2.number);
        System.out.println("year = " + car2.year);
        System.out.println("color = " + car2.color);
        System.out.println("state = " + car2.state);
        System.out.println("km = " + car2.km);
        System.out.println("maxSpeed = " + car2.maxSpeed);

        System.out.println("\n Objectlarning methodlarini ishlatish");

        System.out.println("******************car1****************");
        car1.startOn();
        System.out.println("model = " + car1.model);
        System.out.println("number = " + car1.number);
        System.out.println("year = " + car1.year);
        System.out.println("color = " + car1.color);
        System.out.println("state = " + car1.state);

        System.out.println("******************car2****************");
        car2.startOf();
        System.out.println("model = " + car2.model);
        System.out.println("number = " + car2.number);
        System.out.println("year = " + car2.year);
        System.out.println("color = " + car2.color);
        System.out.println("state = " + car2.state);

        Car car3 = new Car("Captiva", "Qora", "01 A234SS", 2018, 240, 25000, true);
        System.out.println("******************car3****************");
        car2.startOf();
        System.out.println("model = " + car3.model);
        System.out.println("number = " + car3.number);
        System.out.println("year = " + car3.year);
        System.out.println("color = " + car3.color);
        System.out.println("state = " + car3.state);

        Car car4 = new Car("Lacetti", "Blue", "10 S234DD", 2008, 250, 23400, false);
        System.out.println(car4.km);
        System.out.println("car4 ning drive methodini chaqirdi ");
        car4.drive(200);
        System.out.println(car4.km);
    }
}
