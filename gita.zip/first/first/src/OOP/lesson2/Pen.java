package OOP.lesson2;

public class Pen {
    //    propertiesga nom bergan payt ot so'z turkumidagi so'zlardan foydalaniladi
//    String color; Ruchkani uzunligini ahamiyati yo'q
    boolean button;
    //    double length; uzunlikniyam ahamiyati yo'q
//    double diametr; diametrniyam ahamiyati yo'q
//private public default protected
    private double inq;
    String inqColor;
    double inqConsumption; // bitta harf uchun sarflanadigan siyo miqdori;

    //    Constructorni qo'lda yozish
//    Pen(){
//
//    }
//    Pen(double inq, double inqConsumption) {
//        this.inq = inq;
//        this.inqConsumption = inqConsumption;
//    }
//
//    Pen(double inq, String inqColor, double inqConsumption) {
//        this.inq = inq;
//        this.inqColor = inqColor;
//        this.inqConsumption = inqConsumption;
//    }
//
//    Pen(boolean button, double inq, String inqColor, double inqConsumption) {
//        this.button = button;
//        this.inq = inq;
//        this.inqColor = inqColor;
//        this.inqConsumption = inqConsumption;
//    }

//    Constructorni Alt+(Fn) + Insert bilan oson yaratish mumkin;

    public Pen() {
    }

    public Pen(double inq, String inqColor, double inqConsumption) {
        this.inq = inq;
        this.inqColor = inqColor;
        this.inqConsumption = inqConsumption;
    }

    public Pen(boolean button, double inq, String inqColor, double inqConsumption) {
        this.button = button;
        this.inq = inq;
        this.inqColor = inqColor;
        this.inqConsumption = inqConsumption;
    }

    public Pen(double inq, double inqConsumption) {
        this.inq = inq;
        this.inqConsumption = inqConsumption;
    }
    //    Methoda yaratayotgan paytda ish harakat bajaruchni nom beriladi

    public void clickButton() {
//        if(button){
//            button = false;
//        }else{
//            button = true;
//        }
        button = !button;
    }


    //    write methodi
    public void write(String word) {
        if (button) {
            if (inq > 0) {
                System.out.println(word);
                inq -= word.length() * inqConsumption; // yozilgan harflar uchun sihoyni sarflanishi
            } else {
                System.out.println("Ruchkada siyoh qolmagan");
            }

        } else {
            System.out.println("Yozishdan oldin tugmani bosing");
        }
    }

    public void changeStergen(double inq) {
        this.inq = inq;
    }

//    Encapsulation getter va setter

    public boolean isButton() {
        return button;
    }

    public void setButton(boolean button) {
        this.button = button;
    }

    public double getInq() {
        return inq;
    }

    public void setInq(double inq) {
        if (inq > 0)
            this.inq = inq;
    }

    public String getInqColor() {
        return inqColor;
    }

    public void setInqColor(String inqColor) {
        this.inqColor = inqColor;
    }

    public double getInqConsumption() {
        return inqConsumption;
    }

    public void setInqConsumption(double inqConsumption) {
        if (inqConsumption > 0)
            this.inqConsumption = inqConsumption;
    }
}
