package OOP.lesson2;

public class example1 {
    public static void main(String[] args) {
        Pencil ruchka = new Pencil(120, 10, "Ko'k");
        ruchka.clickButton();
        System.out.println(ruchka.getInq());
        ruchka.write("Hello oppdsff");
        System.out.println(ruchka.getInq());
        ruchka.write("Hicho");
        System.out.println(ruchka.getInq());
    }
}

class Pencil {
    private int inq;
    boolean button;
    int inqCunsunption; //bitta harf uchun ketgan siyoh miqdori
    String inqColor;



    public Pencil(int inq, int inqCunsunption, String inqColor) {
        this.inq = inq;
        this.inqCunsunption = inqCunsunption;
        this.inqColor = inqColor;
    }

    public void clickButton() {

        button = !button;
    }

    public void write(String word) {
        if (button) {
            if (inq >= word.length() * inqCunsunption) {
                System.out.println(word);
                inq -= word.length() * inqCunsunption; //yozilgan harflar uchun siyohni sarflanishi
            } else if (inq > 0) {
                System.out.println("Siyoh faqatgina " + inq / inqCunsunption + " ta harfga yetadi: " + word.substring(0, (inq / inqCunsunption)));
                inq -= inq / inqCunsunption * inqCunsunption; //yozilgan harflar uchun siyohni sarflanishi
            } else {
                System.out.println("Ruchkada siyoh qolmagan");
            }
        } else {
            System.out.println("Yozishdan oldin tugmani bosing");
        }
    }

    public boolean isButton() {
        return button;
    }

    public void setButton(boolean button) {
        this.button = button;
    }

    public int getInq() {
        return inq;
    }

    public void setInq(int inq) {
        this.inq = inq;
    }

    public int getInqCunsunption() {
        return inqCunsunption;
    }

    public void setInqCunsunption(int inqCunsunption) {
        this.inqCunsunption = inqCunsunption;
    }

    public String getInqColor() {
        return inqColor;
    }

    public void setInqColor(String inqColor) {
        this.inqColor = inqColor;


    }
}