package OOP.lesson2;

public class Main {
    public static void main(String[] args) {
        Pen ruchka = new Pen(100, "Ko'k", 10);
        ruchka.clickButton();
        System.out.println(ruchka.getInq());
        ruchka.write("Hello OOP!");
        System.out.println(ruchka.getInq());
        ruchka.write("Hi");
//Encapsulation nni vazifasi fieldlarni private va methodlarni publick qilishdan iborat
        System.out.println("=====pen objecti======");
        Pen pen = new Pen();
        pen.setInq(-100);
        pen.setInqColor("Qora");
        pen.setInqConsumption(10);
        System.out.println(pen.getInq());
        pen.clickButton();
        pen.write("Hi");
        System.out.println(pen.getInq());

    }

}
