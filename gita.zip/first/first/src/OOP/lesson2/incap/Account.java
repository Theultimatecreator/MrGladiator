package OOP.lesson2.incap;

public class Account {
    private double accountBalance;
    private int accountNo;

    public Account(double accountBalance, int accountNo) {
        this.accountBalance = accountBalance;
        this.accountNo = accountNo;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public int getAccountNo() {
        return accountNo;
    }

    public void setAccountNumber(int accountNo) {
        this.accountNo = accountNo;
    }
}
