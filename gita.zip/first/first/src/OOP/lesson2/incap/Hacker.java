package OOP.lesson2.incap;

public class Hacker {
        public static void main(String[] args) {
            Account acc1 = new Account(200, 12345);
            int no = 12345;
            double hackerBalance = 0;
            if (no == acc1.getAccountNo()){
                System.out.println("Sizni balansingizda = ");
                hackerBalance += acc1.getAccountBalance();
            }else{
                System.out.println("hato");
            }
        }
    }

