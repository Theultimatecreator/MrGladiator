package OOP.inherr;

public class PhpTeacher extends Teacher {
    public PhpTeacher() {
        this.name = "Asqar";
        this.age = 29;
        this.course = "PHP";
        this.workExperience = 3;

    }

    public void whatdo() {
        System.out.println("PHP dan dars beradi ");
    }
}
