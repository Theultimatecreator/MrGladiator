package OOP.inherr;

public class JavaTeacher extends Teacher {
    public JavaTeacher() {
        this.name = "Bahodir";
        this.age = 29;
        this.course = "Java";
        this.workExperience = 8;
    }

    public void whatdo() {
        System.out.println("Java dan dars beradi ");
    }
}
