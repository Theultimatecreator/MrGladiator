package OOP.inherr;

public class Teacher {
    int age;
    String name;
    String surname;
    String course;
    int workExperience;

    public void show() {
        System.out.println("Teacher's name :" + this.name);
        System.out.println("Teacher age :" + this.surname);
        System.out.println("Teacher course :" + this.course);
        System.out.println("Teacher work experience :" + this.workExperience);
    }
}
