package OOP.inherr;

public class Main {
    public static void main(String[] args) {
        PhpTeacher pteacher = new PhpTeacher();
        JavaTeacher jteacher = new JavaTeacher();
        pteacher.whatdo();
        jteacher.whatdo();
        System.out.println("---------------------------------");
        pteacher.show();
        jteacher.show();
    }
}
