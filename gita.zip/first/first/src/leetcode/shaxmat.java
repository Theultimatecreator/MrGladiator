package leetcode;

public class shaxmat {
}
