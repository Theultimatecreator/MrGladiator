package leetcode;

import java.util.*;

public class string_lower {
    public static void main(String[] args) {
        List<String> list  = Arrays.asList("Mehriddin Haydarov ", "Maksimal SanoNNN");

        list.stream()
                .mapToLong(s -> s.chars().filter(Character::isLowerCase).count())
                .max()
                .ifPresent(System.out::println);
    }
}




