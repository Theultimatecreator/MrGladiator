package PDP;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

public class Week {

    public static void main(String[] args) {
        SimpleDateFormat sdf = new SimpleDateFormat();
        Calendar cal = new GregorianCalendar(2002,04,19);
        System.out.println("date before the date " +sdf.format(cal.getTime()));
        cal.add(Calendar.DAY_OF_MONTH, 3);
        if (sdf.format(cal.getTime()).equals(cal.DAY_OF_WEEK==7)){

        }
        System.out.println("date before the date " + sdf.format(cal.getTime()));


    }
}
