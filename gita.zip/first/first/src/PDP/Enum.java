package PDP;

public class Enum {
    public enum Gender{
        Ayol,
        Erkak
    }

    public static void main(String[] args) {
        Gender ayol = Gender.Ayol;
        Gender erkak = Gender.Erkak;
        System.out.println(ayol);
        System.out.println(erkak);
    }
}
