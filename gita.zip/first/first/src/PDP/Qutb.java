package PDP;

public class Qutb {
    public enum Side{
        Shimol,
        Janub,
        Sharq,
        Garb
    }

    public static void main(String[] args) {
        Side side = Side.Garb;
        System.out.println(side);
        Side[] sides = Side.values();
        for (Side side1 : sides) {
            
        }
    }
}
