package Asal.Asal.Ukasi;

import java.util.Scanner;

public class Dilbekcha {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        int k = 0;
        for (int i = 0; i < str.length(); i++) {
            if ('a' <= str.charAt(i) && str.charAt(i) <= 'z') k++;
            else if ('а' <= str.charAt(i) && str.charAt(i) <= 'я') k++;
        }
        System.out.println("kichik harflar soni = " + k);
    }
}

class string26 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr:");
        String str = in.nextLine();
        int n = in.nextInt();
        int len = str.length();
        if (len > n) {
            str = str.substring(len - n);
        } else if (len < n) {
            for (int i = 0; i < n - len; i++) {
                str = "." + str;
            }
        }
        System.out.println(str);

    }
}

class string27 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr1");
        String s1 = in.next();
        System.out.println("satr2");
        String s2 = in.next();
        System.out.println("n1");
        int n1 = in.nextInt();
        System.out.println("n2");
        int n2 = in.nextInt();
        String newString = "";
        newString += s1.substring(0, n1);
        newString += s2.substring(s2.length() - n2);
        System.out.println(newString);

    }
}

class string28{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        char c = in.next().charAt(0);
        String s = in.next();
        String ans = "";
        for (int i = 0; i < s.length(); i++) {
            ans += s.charAt(i);
            if (s.charAt(i) == c) {
                ans += c;
            }
        }
        System.out.println(ans);
    }
}