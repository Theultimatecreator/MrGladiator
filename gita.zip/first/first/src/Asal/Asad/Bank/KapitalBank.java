package Asal.Asad.Bank;

public class KapitalBank extends Bank {
    KapitalBank(String name) {
        super(name);
    }

    @Override
    public void kredit() {
        System.out.println("Kredit foizi 21%");
    }
}
