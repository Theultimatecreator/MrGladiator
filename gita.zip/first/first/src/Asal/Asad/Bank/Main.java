package Asal.Asad.Bank;

public class Main {
    public static void main(String[] args) {
        Bank bank = new KapitalBank("Ipoteka Bank");
        bank.kredit();
    }
}
