package Asal.Asad;

public class Main {
    public static void main(String[] args) {
        Child child = new Child();
        child.show1();
        child.show2();
    }
}
