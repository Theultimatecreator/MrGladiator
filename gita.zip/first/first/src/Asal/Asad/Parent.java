package Asal.Asad;

public abstract class Parent {
    abstract void show1();

    void show2() {
        System.out.println("oddiy ota methodi");
    }
}
