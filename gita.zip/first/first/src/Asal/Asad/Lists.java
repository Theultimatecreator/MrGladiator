package Asal.Asad;

public class Lists {
    enum daraja {
        quyi,
        orta,
        yuqori
    }

    public static void main(String[] args) {
        for (daraja list : daraja.values()) {
            System.out.println(list);
        }

//        daraja list = daraja.quyi;
//        switch (list) {
//            case orta -> System.out.println("orta daraja");
//            case quyi -> System.out.println("quyi daraja");
//            case yuqori -> System.out.println("yuqori daraja");
//        }
    }
}
