package Asal.Asad;

public class Child extends Parent {
    @Override
    void show1() {
        System.out.println("oddiy bola methodi");
    }


}
