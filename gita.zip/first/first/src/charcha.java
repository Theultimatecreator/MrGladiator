import java.util.Scanner;

public class charcha {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        char b = in.next().charAt(0);//ishoraga
        int c = in.nextInt();
        if (b == '+')
            System.out.println(a + c);
        else if (b == '-')
            System.out.println(a - c);
        else if (b == '*')
            System.out.println(a * c);
        else if (b == '/')
            System.out.println(a / c);
    }
}
