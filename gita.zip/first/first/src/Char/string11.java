package Char;

import java.util.Scanner;

public class string11 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        String c = "";
        for (int i = 0; i < str.length(); i++) {
            c+= str.charAt(i) + " ";

//            c.insert(0, str.charAt(i));
        }
        System.out.println(c.trim());
    }
}
