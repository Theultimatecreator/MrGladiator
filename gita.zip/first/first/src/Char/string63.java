package Char;

import java.util.Scanner;

public class string63 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        int k = in.nextInt();
        String t = "";
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (Character.isLetter(c))
                if (c > 'z' - k & c < 'Z' - k) c -= 25 + k;
                else c+=k;

            t += c;

        }
        System.out.println(t);

    }
}
