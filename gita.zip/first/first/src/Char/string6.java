package Char;

import java.util.Scanner;

public class string6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        char n = in.next().charAt(0);
        if (Character.isDigit(n)) {
            System.out.println("digit");
        } else if (Character.isLetter(n) && n >='A' && n <='z'){
            System.out.println("lotin");
        }else{
            System.out.println(0);
        }
    }
}
