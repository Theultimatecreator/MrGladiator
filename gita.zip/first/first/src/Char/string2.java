package Char;

import java.util.Scanner;

public class string2 {
    public static void main(String[] args) {
        Scanner in  = new Scanner(System.in);
        int n = in.nextInt();
        System.out.println((char) n);
    }
}
