package Char;

import java.util.Scanner;

public class string14 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        int k = 0;
        for (int i = 0; i < str.length(); i++) {
            if ('A' <= str.charAt(i) && 'Z' >= str.charAt(i))
                k++;
        }
        System.out.println("katta harf: " + k + " ta");
    }
}
