package Char;

import java.util.Scanner;

public class string60 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        int n = str.indexOf("\\") + 1;
        String str1 = str.substring(n);
        int m = str1.indexOf("\\") + n;
        String satr = str.substring(n, m);
        System.out.println(satr);

    }
}
