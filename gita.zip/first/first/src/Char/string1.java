package Char;

import java.util.Scanner;

public class string1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        char input = in.next().charAt(0);
        System.out.println((int) input);

    }
}
