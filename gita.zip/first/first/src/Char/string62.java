package Char;

import java.util.Scanner;

public class string62 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        String t = "";
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (Character.isLetter(c))
                if (c == 'z' || c == 'Z') c -= 25;
                else c++;

            t += c;

        }
        System.out.println(t);

    }
}
