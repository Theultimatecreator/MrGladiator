package Char;

import java.util.Scanner;

public class string28 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        char c = in.next().charAt(0);
        System.out.println("string");
        String s = in.next();
        String temp = "";
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == c) {
                temp += s.charAt(i) + "" + s.charAt(i);
            } else {
                temp += s.charAt(i);
            }
        }
        s = temp;
        System.out.println(s);
    }
}
