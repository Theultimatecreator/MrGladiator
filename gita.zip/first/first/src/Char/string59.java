package Char;

import java.util.Scanner;

public class string59 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        int n = str.lastIndexOf("\\");
        int m = str.lastIndexOf(".");
        str = str.substring(m);
        System.out.println(str);
    }
}
