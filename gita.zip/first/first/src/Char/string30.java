package Char;

public class string30 {
    public static void main(String[] args) {

    }
}
