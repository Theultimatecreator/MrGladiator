package Char;

import java.util.Arrays;
import java.util.Scanner;

public class string51 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        str = str.replaceAll(" {2,} ", " ");

        String a[] = str.split(" ");
        Arrays.sort(a);

        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
    }
}
