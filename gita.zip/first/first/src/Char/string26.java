package Char;

import java.util.Scanner;

public class string26 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("string:");
        String str = in.nextLine();
        int n = in.nextInt();
        int len = str.length();

        if(len > n){
            str = str.substring(len - n);
        }else if(len < n){
            for (int i = 0; i < n - len; i++) {
                str = "." + str;
            }
        }
        System.out.println(str);

    }
}
