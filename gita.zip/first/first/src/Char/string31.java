package Char;

import java.util.Scanner;

public class string31 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr1");
        String str1 = in.nextLine();
        System.out.println("satr2");
        String str2 = in.nextLine();
        System.out.println(str1.contains(str2));
    }
}
