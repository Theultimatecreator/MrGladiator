package Char;

import java.util.Arrays;
import java.util.Scanner;

public class string52 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        str = str.replaceAll(" {2,} ", " ");

        String a[] = str.split(" ");

        for (int i = 0; i < a.length; i++) {
            a[i] = a[i].substring(0, 1).toUpperCase() + a[i].substring(1);
//            a[i] = a[i].replaceFirst(a[i].charAt(0) + "", ((char) (a[i].charAt(0) + 'A' - 'a') + ""));
            System.out.print(a[i] + " ");
        }
    }
}

class string53{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = "Welcome$%$?? to*&^ java@#$ lesso$%^ns";

        int l = str.length() - str.replaceAll("\\p{Punct}", "").length();
        System.out.println(l);
    }
}
