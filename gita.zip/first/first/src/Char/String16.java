package Char;

import java.util.Scanner;

public class String16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        String a = "";
        char k;
        for (int i = 0; i < str.length(); i++) {
            if ('A' <= str.charAt(i) && 'Z' >= str.charAt(i))
                k = (char) ('a' + str.charAt(i) - 'A');
            else
                k = str.charAt(i);
            a+=k;
        }
        str = a;
        System.out.println(str);
    }
}


class leeter1{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        String a[]=str.split("");

        for (int i = 0; i < str.length(); i++) {
            if (a[i].equals(a[i].toUpperCase())){
                a[i]=a[i].toLowerCase();
            }
            System.out.print(a[i]);
        }
    }
}