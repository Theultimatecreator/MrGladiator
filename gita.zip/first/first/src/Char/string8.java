package Char;

import java.util.Scanner;

public class string8 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        char k = in.next().charAt(0);
        for (int i = 0; i < n; i++) {
            System.out.print(k + " ");
        }
    }
}
