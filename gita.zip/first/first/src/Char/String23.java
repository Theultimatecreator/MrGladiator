package Char;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.util.Scanner;

public class String23 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("DIQQAT : son bir xonalik bolishi kerak!");
        String str = in.nextLine();
        int k = 0;
        char y = str.charAt(0);
        String r = Character.toString(y);
        int h = Integer.parseInt(r);
        k += h;
        for (int i = 2; i < str.length(); i+=2) {
            char e = str.charAt(i);
            if (e == '+') {
                char q = str.charAt(i + 2);
                String w = Character.toString(q);
                int c = Integer.parseInt(w);
                k += c;
            }
            if (e == '-') {
                char q = str.charAt(i + 2);
                String w = Character.toString(q);
                int c = Integer.parseInt(w);
                k -= c;
            }
        }
        System.out.println(k);

    }
}
class addNumber{
    public static void main(String[] args) throws ScriptException {
        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("js");
        Object result = engine.eval("4*5");

    }
}