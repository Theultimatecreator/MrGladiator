package Char;

import java.util.Locale;
import java.util.Scanner;

public class lesson1 {
    public static void main(String[] args) {
//        int long short byte
//        float double
//        boolean
//        char 2 bayt 16 bit[0; 2^16-1]
        Scanner in = new Scanner(System.in);
//        String str = "Asadbek Fayzullayev";
        String str2 = in.nextLine();
//        System.out.println(str);
        str2 = str2.toUpperCase();
        str2 = str2 + " Dasturchi";
        System.out.println(str2);
        str2 = str2.toLowerCase();
        System.out.println(str2);
        str2 = str2.concat(" Dasturchi");
        System.out.println(str2);


//        int a = in.nextInt();
//        char c = in.next().charAt(0);
//        int b = in.nextInt();
//
//        if (c =='-'){
//            System.out.print(a - b);
//        }else if(c == '+'){
//            System.out.println(a + b);
//        }else if(c=='*'){
//            System.out.println(a * b);
//        }else
//            System.out.println(a / b);

//        char letter = 61510;

//
//
////        int k = letter;
//
//        System.out.println(letter);
//        System.out.println(letter);

//        System.out.println((char) 60243);


//        char letter = 'A';
//        char letter2 = 65;
//        for (int i = 0; i < n; i++) {
//            System.out.print((int) letter++ + " ");
//        }
//        System.out.println();
//        for (int i = 0; i < n; i++) {
//            System.out.print((char) letter2++ + "   ");
//        }
//        System.out.println();
//        System.out.println();
//
//        char letterA = 'A';
//        char letterMin = 'a';
//        for (int i = 0; i < n; i++) {
//            System.out.print(letterA++);
//            System.out.print(letterMin++ + " ");
//        }
    }
}
