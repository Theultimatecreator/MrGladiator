package Char;

import java.util.Scanner;

public class string19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        //123
//        for (int i = 0; i < 4; i++) {
//            str = str.replace("" + i, "");
//        }
//        int k = str.length()>=2?0:str.contains(".")?2:str.length()==1?0:1;
//        System.out.println(k);
    }
}
