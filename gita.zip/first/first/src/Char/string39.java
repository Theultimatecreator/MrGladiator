package Char;

import java.util.Scanner;

public class string39 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str1 = in.nextLine();
        String temp = "";
        String array[] = str1.split(" ");
        if (array.length > 2) temp = array[1];
        System.out.println(temp);
    }
}
