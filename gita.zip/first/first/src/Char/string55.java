package Char;

import java.util.Scanner;

public class string55 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        String a[] = str.split(" ");
        int max = 0;
        String t = "";
        for (int i = 0; i < a.length; i++) {
            if (a[max].length()<a[i].length()){
                max = i;
            }
        }
        System.out.print(a[max]);
    }
}
