package Char;

import java.util.Scanner;

public class string27 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr1:");
        String s1 = in.next();
        System.out.println("satr1:");
        String s2 = in.next();
        System.out.print("n1:");
        int n1 = in.nextInt();
        System.out.print("n2:");
        int n2 = in.nextInt();
        String newSting = "";
        newSting += s1.substring(0, n1);
        newSting += s2.substring(s2.length() - n2);

        System.out.println(newSting);
    }
}


