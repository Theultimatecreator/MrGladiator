package Char;

import java.util.Scanner;

public class string13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr");
        String str = in.nextLine();
        int k = 0;

        for (int i = 0; i < str.length(); i++) {
            if (Character.isDigit(str.charAt(i))){
                k++;
            }
        }
        System.out.println("raqamlar soni:" + k);
    }
}
