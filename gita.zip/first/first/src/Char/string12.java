package Char;

import java.util.Scanner;

public class string12 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr:");
        String s = in.nextLine();
        System.out.println("n :");
        int n = in.nextInt();
        String str1 = "";
        String str = "";
        for (int i = 0; i < n; i++) {
            str1 += "*";
        }
//        S***alom
        for (int i = 0; i < s.length()-1; i++) {
            str +=s.charAt(i) + str1;

        }
        str+=s.charAt(s.length() - 1);
        System.out.println(str);
    }
}
