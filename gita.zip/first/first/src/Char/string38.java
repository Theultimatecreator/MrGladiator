package Char;

import java.util.Scanner;

public class string38 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str1 = in.nextLine();
        String str2 = in.nextLine();
        String str3 = in.nextLine();
        str1 = str1.replace(str2, str3);
        System.out.println(str1);
    }
}
