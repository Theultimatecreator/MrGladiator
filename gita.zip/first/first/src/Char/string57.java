package Char;

import java.util.Scanner;

public class string57 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        str = str.replaceAll(" {2,} ", " ").trim();
        System.out.println(str);


    }
}
