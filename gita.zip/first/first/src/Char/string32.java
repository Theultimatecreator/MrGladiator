package Char;

import java.util.Scanner;

public class string32 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("satr1");
        String str1 = in.nextLine();
        System.out.println("satr2");
        String str2 = in.nextLine();
        int k = 0;
        while (str1.contains(str2)) {
            k++;
            str1 = str1.replaceFirst(str2, "");
        }
        System.out.println(k);
    }
}
