package Char;

import java.util.Scanner;

public class string37 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str1 = in.nextLine();
        String str2 = in.nextLine();
        String str3 = in.nextLine();
        int l = str1.lastIndexOf(str2);
        if (l >= 0) {
            str1 = str1.substring(0, l) + str3 + str1.substring(l + str2.length());
        }
        System.out.println(str1);
    }
}
