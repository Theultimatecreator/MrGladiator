package Char;

import java.util.Scanner;

public class String15 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        int k = 0;
        for (int i = 0; i < str.length(); i++) {
            if ('a' <= str.charAt(i) && 'z' >= str.charAt(i)) k++;
            else if('а'<=str.charAt(i) && 'я' >= str.charAt(i)) k++;
        }
        System.out.println(k);
    }
}
