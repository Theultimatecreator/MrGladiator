package Char;

import java.util.Scanner;

public class string44 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str1 = in.nextLine();
        String[] a = str1.split(" ");

        int count = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i].contains("A")){
                count++;
            }

        }
        for (int i = 0; i < a.length; i++) {
            if (count == 3){
                System.out.println(str1);
            }
        }
    }
}
