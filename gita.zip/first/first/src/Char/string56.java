package Char;

import java.util.Scanner;

public class string56 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        String a[] = str.split(" ");
        int min = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[min].length()>=a[i].length()){
                min = i;
            }
        }
        System.out.print(a[min]);
    }
}
